package com.voidhunt;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_9779;
import net.minecraft.server.MinecraftServer;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public class VoidHuntClient implements ClientModInitializer {
    private static boolean huntMode  = true;
    private static boolean aimAssist = true;
    private static boolean lastUse   = false;   // edge-detect right click
    private static boolean lastH     = false;   // edge-detect H key
    private static boolean lastK     = false;   // edge-detect K key
    private static boolean lastL     = false;   // edge-detect L key (ultimate)
    private static boolean lastG     = false;   // edge-detect G key (domain expansion)
    private static class_1309 target;
    private static class_1309 attackedTarget = null; // for kill counting
    private static int kills = 0, combo = 0, comboTimer = 0;

    // ---- ultimate (orbital strike satellite) ----
    private static int ultTimer = 0;
    private static final int    ULT_TICKS  = 200;   // 10 seconds
    private static final double ULT_HEIGHT = 7.0;
    private static final double ULT_RADIUS = 24.0;
    private static final float  ULT_DMG    = 20.0f;

    // ---- DOMAIN EXPANSION: 領域展開 · 기계의 세계 (MACHINE WORLD) ----
    private static int    domainTimer = 0;
    private static class_243  domainCenter = null;
    private static final int    DOMAIN_TICKS  = 240;   // 12 seconds
    private static final double DOMAIN_RADIUS = 16.0;  // enclosed space radius
    private static final float  DOMAIN_DMG    = 6.0f;  // sure-hit tick damage
    private static final double FREEZE_RADIUS = 320.0; // 20 chunks — everything (but caster) is frozen here
    private static final java.util.Map<UUID, class_243> frozen = new java.util.HashMap<>();

    // ===== CROW FAN KIT — held-weapon skill set (까마귀의 부채) =====
    private static boolean lastR = false, lastC = false, lastV = false, lastX = false;
    private static int    crowDomainTimer = 0;
    private static class_243  crowCenter = null;
    private static final int    CROW_DOMAIN_TICKS = 300;  // 15 seconds
    private static final double CROW_RADIUS       = 30.0; // a far bigger world
    private static final float  CROW_DMG          = 5.0f; // domain tick damage
    private static int wingsTimer = 0;
    private static final int WINGS_TICKS = 160;
    private static int   sealTimer = 0;
    private static class_243 sealCenter = null;
    private static final int SEAL_TICKS = 50;
    private static final List<Crow> crows = new ArrayList<>();
    private static final int    MAX_CROWS = 8;
    private static final double CROW_ATTACK_RANGE = 18.0;
    private static final float  CROW_PECK_DMG = 7.0f;
    private static final int GRN = 0xFF8CF06A, PUR = 0xFFB98CFF, BON = 0xFFE6E2D8;

    // ===== DUEL ARENA — 전사들의 결투장 (held Duel Greatsword) =====
    private static boolean lastB = false;
    private static int    arenaTimer = 0;
    private static class_243  arenaCenter = null;
    private static UUID   opponentId = null;
    private static String opponentName = "—";
    private static final int    ARENA_TICKS  = 400;   // 20 seconds
    private static final double ARENA_RADIUS = 18.0;
    private static final int GLD = 0xFFF2C044, CRM = 0xFFE23C46;
    private static class_1309 opponentEntity = null;

    // ===== multiplayer effect sharing =====
    private static boolean renderingRemote = false;   // true while painting someone else's effects
    private static final java.util.Map<UUID, VoidNet.Fx> REMOTE = new java.util.HashMap<>();
    // sword skills: 광폭화 / 혈검술 / 전사의 심판
    private static boolean lastZ = false, lastN = false;
    private static int berserkTimer = 0;
    private static final int BERSERK_TICKS = 240;   // 12s frenzy
    private static int   slashTimer = 0;
    private static class_243 slashPos = null, slashDir = null;
    private static final int SLASH_TICKS = 16;
    private static final float SLASH_DMG = 30.0f;
    private static int    judgmentTimer = 0;
    private static boolean judgmentDone = false;
    private static class_243  judgmentPos = null;
    private static final int JUDGE_TICKS = 50;

    // ===== OCEAN WORLD — 바다의 세계 (held Sea Trident) =====
    private static boolean lastJ = false, lastU = false, lastY = false, lastM = false;
    private static int    seaTimer = 0;
    private static class_243  seaCenter = null;
    private static final int    SEA_TICKS  = 300;   // 15s
    private static final double SEA_RADIUS = 28.0;
    private static final float  SEA_DMG    = 5.0f;
    private static int   waveTimer = 0;
    private static class_243 wavePos = null, waveDir = null;
    private static final int WAVE_TICKS = 18;
    private static int   maelTimer = 0;
    private static class_243 maelPos = null;
    private static final int MAEL_TICKS = 70;
    private static final List<Crow> sharks = new ArrayList<>();
    private static final int MAX_SHARKS = 6;
    private static final int AQUA = 0xFF44E0E0, SEAB = 0xFF5AA6FF;

    private static final double RANGE = 20.0;   // detection radius
    private static final double REACH = 3.0;    // melee reach
    private static final float  AIM   = 0.20f;  // aim-assist strength

    // ---- drones ----
    private static final List<Drone> drones = new ArrayList<>();
    private static final int    MAX_DRONES = 4;
    private static final double DRONE_RANGE = 14.0;
    private static final float  DRONE_DMG   = 20.0f;  // laser damage (was 4)

    private static final int CY=0xFF41E9FF, AMB=0xFFFFB638, DIM=0xFF5B7C8A, RED=0xFFFF4D6D, VIO=0xFFB98CFF;

    private static final class_1799 DRONE_STACK = new class_1799(VoidHunt.VOID_DRONE);
    private static final class_1799 SAT_STACK   = new class_1799(VoidHunt.VOID_SATELLITE);
    private static final class_1799 GEAR_STACK  = new class_1799(VoidHunt.VOID_GEAR);
    private static final class_1799 CORE_STACK  = new class_1799(VoidHunt.VOID_CORE);
    private static final class_1799 CROW_STACK  = new class_1799(VoidHunt.CROW);
    private static final class_1799 TOMB_STACK  = new class_1799(VoidHunt.TOMBSTONE);
    private static final class_1799 TORII_STACK = new class_1799(VoidHunt.TORII);
    private static final class_1799 TREE_STACK  = new class_1799(VoidHunt.DEAD_TREE);
    private static final class_1799 MONU_STACK  = new class_1799(VoidHunt.GRAVE_MONUMENT);
    private static final class_1799 GALLOWS_STACK = new class_1799(VoidHunt.GALLOWS_CAGE);
    private static final class_1799 SPIKE_STACK   = new class_1799(VoidHunt.SKULL_SPIKE);
    private static final class_1799 PILLAR_STACK  = new class_1799(VoidHunt.ARENA_PILLAR);
    private static final class_1799 ARCH_STACK    = new class_1799(VoidHunt.ARENA_ARCH);
    private static final class_1799 HAND_STACK    = new class_1799(VoidHunt.GOD_HAND);
    private static final class_1799 SHARK_STACK   = new class_1799(VoidHunt.SHARK);
    private static final class_1799 CORAL_STACK   = new class_1799(VoidHunt.CORAL_PILLAR);
    private static final class_1799 TEMPLE_STACK  = new class_1799(VoidHunt.SEA_TEMPLE);

    static final class Drone {
        class_243 pos; class_243 goal; int idx; int cd = 0;
        Drone(class_243 p, int idx){ this.pos = p; this.idx = idx; }
    }
    static final class Crow {
        class_243 pos; double face; int idx; int cd = 0;
        Crow(class_243 p, int idx){ this.pos = p; this.idx = idx; }
    }

    @Override
    public void onInitializeClient() {
        // Keys are read RAW (InputUtil) instead of registered keybinds,
        // to bypass saved-binding / conflict issues entirely.
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register(this::onHud);
        WorldRenderEvents.AFTER_ENTITIES.register(this::onWorldRender);
        // receive other players' effect snapshots
        ClientPlayNetworking.registerGlobalReceiver(VoidNet.SyncS2C.ID, (payload, context) ->
            context.client().execute(() -> {
                VoidNet.Fx fx = payload.fx(); fx.age = 0;
                REMOTE.put(payload.owner(), fx);
            }));
    }

    // Render the 3D drone model at each drone's world position.
    private void onWorldRender(WorldRenderContext ctx) {
        class_4587 ms = ctx.matrixStack();
        if (ms == null) return;
        class_4597 vcp = ctx.consumers();
        class_4184 cam = ctx.camera();
        net.minecraft.class_243 camPos = cam.method_19326();
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        float spin = mc.field_1724.field_6012 * 2.0f;
        int light = class_765.method_23687(15, 15);
        // DOMAIN structures (gears + central reactor core)
        if (domainTimer > 0 && domainCenter != null)
            renderDomain(ms, vcp, mc, camPos, light);
        // CROW GRAVE world + summoned crows
        if (crowDomainTimer > 0 && crowCenter != null)
            renderCrowWorld(ms, vcp, mc, camPos, light);
        // DUEL ARENA colosseum
        if (arenaTimer > 0 && arenaCenter != null)
            renderArena(ms, vcp, mc, camPos, light);
        // OCEAN WORLD (sunken temple, coral, sharks)
        if (seaTimer > 0 && seaCenter != null)
            renderSeaWorld(ms, vcp, mc, camPos, light);
        for (Crow sk : sharks)
            renderModel(SHARK_STACK, ms, vcp, mc, camPos, light, sk.pos.field_1352, sk.pos.field_1351, sk.pos.field_1350, 1.1f, (float) sk.face, 0f, false);
        // 전사의 심판 — the giant God-Warrior hand descends onto the doomed foe
        if (judgmentTimer > 0 && judgmentPos != null) {
            int el = JUDGE_TICKS - judgmentTimer;
            float prog = Math.min(1f, el / 22f);
            double startY = judgmentPos.field_1351 + 30;
            double curY = startY - (startY - (judgmentPos.field_1351 + 2.5)) * prog;
            renderModel(HAND_STACK, ms, vcp, mc, camPos, light, judgmentPos.field_1352, curY, judgmentPos.field_1350, 6.0f, 0f, 0f, false);
        }
        for (Crow cw : crows) {
            renderModel(CROW_STACK, ms, vcp, mc, camPos, light, cw.pos.field_1352, cw.pos.field_1351, cw.pos.field_1350,
                0.9f, (float) cw.face, 0f, false);
        }
        for (Drone d : drones) {
            ms.method_22903();
            ms.method_22904(d.pos.field_1352 - camPos.field_1352, d.pos.field_1351 - camPos.field_1351, d.pos.field_1350 - camPos.field_1350);
            ms.method_22905(0.8f, 0.8f, 0.8f);
            ms.method_22907(class_7833.field_40716.rotationDegrees(spin));
            ms.method_22904(-0.5, -0.5, -0.5); // center the 1-block item model
            mc.method_1480().method_23178(DRONE_STACK, class_811.field_4319,
                light, class_4608.field_21444, ms, vcp, mc.field_1687, 0);
            ms.method_22909();
        }
        // ULTIMATE satellite hovering above the player
        if (ultTimer > 0 && mc.field_1724 != null) {
            class_243 sat = mc.field_1724.method_33571().method_1031(0, ULT_HEIGHT, 0);
            ms.method_22903();
            ms.method_22904(sat.field_1352 - camPos.field_1352, sat.field_1351 - camPos.field_1351, sat.field_1350 - camPos.field_1350);
            ms.method_22905(4.0f, 4.0f, 4.0f);
            ms.method_22907(class_7833.field_40716.rotationDegrees(mc.field_1724.field_6012 * 3.0f));
            ms.method_22904(-0.5, -0.5, -0.5);
            mc.method_1480().method_23178(SAT_STACK, class_811.field_4319,
                light, class_4608.field_21444, ms, vcp, mc.field_1687, 0);
            ms.method_22909();
        }
        // paint every other player's shared effects
        if (!REMOTE.isEmpty())
            for (var e : REMOTE.entrySet()) renderRemote(e.getKey(), e.getValue(), ms, vcp, mc, camPos, light);
    }

    // Render the machine-world structures inside the domain: a central reactor
    // core, standing gears around the perimeter, and big gears on the floor.
    private void renderDomain(class_4587 ms, class_4597 vcp, class_310 mc,
                              class_243 camPos, int light) {
        class_243 ctr = domainCenter;
        float age = mc.field_1724.field_6012;
        int elapsed = DOMAIN_TICKS - domainTimer;
        float rise = Math.min(1.0f, elapsed / 14.0f);   // structures rise as domain forms

        // ---- central reactor core (grand centerpiece), grows in and stands on the floor ----
        float cScale = 2.4f * (0.25f + 0.75f * rise);
        double coreHalf = (23.75 / 16.0) * cScale;       // half-height so the base sits on the floor
        double cy = ctr.field_1351 + coreHalf;
        ms.method_22903();
        ms.method_22904(ctr.field_1352 - camPos.field_1352, cy - camPos.field_1351, ctr.field_1350 - camPos.field_1350);
        ms.method_22905(cScale, cScale, cScale);
        ms.method_22907(class_7833.field_40716.rotationDegrees(age * 0.6f));
        ms.method_22904(-0.5, -0.5, -0.5);
        mc.method_1480().method_23178(CORE_STACK, class_811.field_4319,
            light, class_4608.field_21444, ms, vcp, mc.field_1687, 0);
        ms.method_22909();

        // ---- colossal SKY HALO gear crowning the whole arena ----
        renderGear(ms, vcp, mc, camPos, light, ctr.field_1352, ctr.field_1351 + 26 * rise, ctr.field_1350,
            11.0f * (0.3f + 0.7f * rise), 0f, age * 0.4f, false);

        // ---- central GEAR TOWER: big concentric rings stacked up the core beam ----
        float[] towScale = {6.5f, 5.6f, 4.8f, 4.0f, 3.2f, 2.4f};
        for (int i = 0; i < towScale.length; i++) {
            double ty = ctr.field_1351 + (4.5 + i * 3.6) * rise;
            float sc = towScale[i] * (0.25f + 0.75f * rise);
            renderGear(ms, vcp, mc, camPos, light, ctr.field_1352, ty, ctr.field_1350, sc,
                0f, age * ((i % 2 == 0) ? 1.1f : -1.1f), false);
        }

        // ---- perimeter SPIRE TOWERS (smaller cores ring the arena like a machine city) ----
        int TOWERS = 6;
        for (int i = 0; i < TOWERS; i++) {
            double a = i * (Math.PI * 2 / TOWERS) + Math.PI / TOWERS;
            double tx = ctr.field_1352 + Math.cos(a) * (DOMAIN_RADIUS * 1.08);
            double tz = ctr.field_1350 + Math.sin(a) * (DOMAIN_RADIUS * 1.08);
            float sc = 1.35f * (0.25f + 0.75f * rise);
            double th = (23.75 / 16.0) * sc;
            ms.method_22903();
            ms.method_22904(tx - camPos.field_1352, (ctr.field_1351 + th) - camPos.field_1351, tz - camPos.field_1350);
            ms.method_22905(sc, sc, sc);
            ms.method_22907(class_7833.field_40716.rotationDegrees(age * 0.3f + i * 30));
            ms.method_22904(-0.5, -0.5, -0.5);
            mc.method_1480().method_23178(CORE_STACK, class_811.field_4319,
                light, class_4608.field_21444, ms, vcp, mc.field_1687, 0);
            ms.method_22909();
        }

        // ---- standing gears around the perimeter (like cogs on the dome wall) ----
        int RINGN = 8;
        double rr = DOMAIN_RADIUS * 0.92;
        for (int i = 0; i < RINGN; i++) {
            double theta = i * (Math.PI * 2 / RINGN) + age * 0.01;
            double gx = ctr.field_1352 + Math.cos(theta) * rr;
            double gz = ctr.field_1350 + Math.sin(theta) * rr;
            double gy = ctr.field_1351 + (2.5 + (i % 3) * 2.5) * rise;
            float facing = (float) Math.toDegrees(theta);
            float gspin = age * ((i % 2 == 0) ? 3.5f : -3.5f);
            renderGear(ms, vcp, mc, camPos, light, gx, gy, gz, 2.8f, facing, gspin, true);
        }

        // ---- floating gears drifting at mid-air, varied sizes/tilt ----
        int FLOAT = 6;
        for (int i = 0; i < FLOAT; i++) {
            double a = i * (Math.PI * 2 / FLOAT) + age * 0.006;
            double fx = ctr.field_1352 + Math.cos(a) * (DOMAIN_RADIUS * 0.68);
            double fz = ctr.field_1350 + Math.sin(a) * (DOMAIN_RADIUS * 0.68);
            double fy = ctr.field_1351 + (7.0 + (i % 4) * 3.0) * rise
                        + Math.sin((age * 0.03) + i) * 0.8;
            float sc = (1.6f + (i % 3) * 0.7f);
            renderGear(ms, vcp, mc, camPos, light, fx, fy, fz, sc,
                (float) Math.toDegrees(a), age * ((i % 2 == 0) ? 2.2f : -2.2f), true);
        }

        // ---- big flat gears on the floor ----
        renderGear(ms, vcp, mc, camPos, light, ctr.field_1352, ctr.field_1351 + 0.15, ctr.field_1350, 5.0f, 0f, age * 1.4f, false);
        int FLOORN = 6;
        for (int i = 0; i < FLOORN; i++) {
            double a = i * (Math.PI * 2 / FLOORN) + Math.PI / FLOORN;
            double fx = ctr.field_1352 + Math.cos(a) * (DOMAIN_RADIUS * 0.6);
            double fz = ctr.field_1350 + Math.sin(a) * (DOMAIN_RADIUS * 0.6);
            renderGear(ms, vcp, mc, camPos, light, fx, ctr.field_1351 + 0.1, fz, 2.4f,
                0f, age * ((i % 2 == 0) ? -2.6f : 2.6f), false);
        }
    }

    private void renderGear(class_4587 ms, class_4597 vcp, class_310 mc,
                            class_243 camPos, int light, double x, double y, double z,
                            float scale, float facing, float spin, boolean upright) {
        ms.method_22903();
        ms.method_22904(x - camPos.field_1352, y - camPos.field_1351, z - camPos.field_1350);
        ms.method_22905(scale, scale, scale);
        if (upright) {
            ms.method_22907(class_7833.field_40716.rotationDegrees(facing));
            ms.method_22907(class_7833.field_40714.rotationDegrees(90));
        }
        ms.method_22907(class_7833.field_40716.rotationDegrees(spin));
        ms.method_22904(-0.5, -0.5, -0.5);
        mc.method_1480().method_23178(GEAR_STACK, class_811.field_4319,
            light, class_4608.field_21444, ms, vcp, mc.field_1687, 0);
        ms.method_22909();
    }

    // Generic world model renderer (upright=false: stand normally & face; true: lay flat like a disc).
    private void renderModel(class_1799 stack, class_4587 ms, class_4597 vcp, class_310 mc,
                             class_243 camPos, int light, double x, double y, double z,
                             float scale, float facing, float spin, boolean upright) {
        ms.method_22903();
        ms.method_22904(x - camPos.field_1352, y - camPos.field_1351, z - camPos.field_1350);
        ms.method_22905(scale, scale, scale);
        ms.method_22907(class_7833.field_40716.rotationDegrees(facing));
        if (upright) ms.method_22907(class_7833.field_40714.rotationDegrees(90));
        if (spin != 0) ms.method_22907(class_7833.field_40716.rotationDegrees(spin));
        ms.method_22904(-0.5, -0.5, -0.5);
        mc.method_1480().method_23178(stack, class_811.field_4319,
            light, class_4608.field_21444, ms, vcp, mc.field_1687, 0);
        ms.method_22909();
    }

    private boolean heldFan(class_310 c) {
        return c.field_1724 != null
            && (c.field_1724.method_6047().method_31574(VoidHunt.CROW_FAN)
             || c.field_1724.method_6079().method_31574(VoidHunt.CROW_FAN));
    }

    private boolean shadesOn(class_310 c) {
        return c.field_1724 != null
            && c.field_1724.method_6118(class_1304.field_6169).method_31574(VoidHunt.VOID_SHADES);
    }
    private boolean active(class_310 c) { return huntMode && shadesOn(c); }

    private void onTick(class_310 c) {
        // RAW key reads (edge-detected) — no keybind system, no conflicts
        long win = c.method_22683().method_4490();
        boolean noScreen = c.field_1755 == null;
        boolean hNow = noScreen && class_3675.method_15987(win, GLFW.GLFW_KEY_H);
        boolean kNow = noScreen && class_3675.method_15987(win, GLFW.GLFW_KEY_K);
        boolean lNow = noScreen && class_3675.method_15987(win, GLFW.GLFW_KEY_O);
        boolean gNow = noScreen && class_3675.method_15987(win, GLFW.GLFW_KEY_G);
        if (hNow && !lastH) huntMode = !huntMode;
        if (kNow && !lastK && arenaTimer <= 0) toggleDrones(c);   // no summons inside the arena
        if (lNow && !lastL && shadesOn(c) && ultTimer <= 0 && arenaTimer <= 0) {  // ULTIMATE
            if (drones.size() < MAX_DRONES) spawnDrones(c);
            ultTimer = ULT_TICKS;
        }
        if (gNow && !lastG && shadesOn(c) && domainTimer <= 0 && c.field_1724 != null) {  // DOMAIN EXPANSION
            domainTimer = DOMAIN_TICKS;
            domainCenter = c.field_1724.method_19538();
        }
        lastH = hNow; lastK = kNow; lastL = lNow; lastG = gNow;
        target = null;

        if (c.field_1724 == null || c.field_1687 == null || c.field_1761 == null) return;

        // CROW FAN kit runs independently of the shades (only needs the fan in hand)
        tickCrowKit(c);
        // DUEL ARENA kit — only needs the Duel Greatsword in hand
        tickArenaKit(c);
        // OCEAN WORLD kit — only needs the Sea Trident in hand
        tickSeaKit(c);
        // multiplayer: broadcast my effects, paint everyone else's
        sendLocalFx(c);
        tickRemotes(c);

        // kill tracking: a target we hit has died
        if (attackedTarget != null && (attackedTarget.method_31481() || !attackedTarget.method_5805())) {
            kills++; combo++; comboTimer = 200; attackedTarget = null;
        }
        if (comboTimer > 0) { comboTimer--; if (comboTimer == 0) combo = 0; }

        if (!shadesOn(c)) { drones.clear(); ultTimer = 0; domainTimer = 0; frozen.clear(); return; }

        if (ultTimer > 0) tickUltimate(c);
        if (domainTimer > 0) { tickDomain(c); domainTimer--; if (domainTimer == 0) frozen.clear(); }

        // ---- AUTO-TARGET + AIM + ATTACK (only while hunt mode on) ----
        if (active(c)) {
            class_238 box = c.field_1724.method_5829().method_1014(RANGE);
            // lock on to hostiles AND other players (never yourself), only if visible
            List<class_1309> foes = c.field_1687.method_8390(class_1309.class, box,
                e -> e.method_5805() && e != c.field_1724 && c.field_1724.method_6057(e)
                    && ((e instanceof class_1588) || (e instanceof class_1657)));
            target = foes.stream().min(Comparator.comparingDouble(c.field_1724::method_5858)).orElse(null);

            if (target != null) {
                if (aimAssist) aimAt(c.field_1724, target);
                boolean inReach = c.field_1724.method_5858(target) <= REACH * REACH;
                boolean charged = c.field_1724.method_7261(0.0f) >= 1.0f;
                if (inReach && charged) {
                    c.field_1761.method_2918(c.field_1724, target);
                    c.field_1724.method_6104(class_1268.field_5808);
                    attackedTarget = target;
                }
            }
            // AUTO-AIM projectiles: home the player's arrows/projectiles onto the target
            steerProjectiles(c);
        }

        // ---- DRONE COMMAND: right-click sends drones to the looked-at spot ----
        boolean useNow = c.field_1690.field_1904.method_1434();
        if (useNow && !lastUse && !drones.isEmpty()) {
            class_243 g = (c.field_1765 != null)
                ? c.field_1765.method_17784()
                : c.field_1724.method_33571().method_1019(c.field_1724.method_5828(1.0f).method_1021(10.0));
            for (Drone d : drones) d.goal = g;
        }
        lastUse = useNow;

        tickDrones(c);
        if (ultTimer > 0) ultTimer--;
    }

    // Steer any player-fired projectiles toward the locked target so they always hit.
    private void steerProjectiles(class_310 c) {
        if (target == null || c.field_1724 == null || c.field_1687 == null) return;
        class_746 p = c.field_1724;
        class_243 aim = target.method_5829().method_1005();
        List<class_1676> projs = c.field_1687.method_8390(class_1676.class,
            p.method_5829().method_1014(64.0), pr -> pr.method_24921() == p);
        MinecraftServer server = c.method_1576();
        for (class_1676 pr : projs) {
            class_243 dir = aim.method_1020(pr.method_19538());
            if (dir.method_1027() < 0.5) continue;
            double speed = Math.max(pr.method_18798().method_1033(), 1.2);
            final class_243 nv = dir.method_1029().method_1021(speed);
            pr.method_18799(nv);
            if (server != null) {
                final UUID id = pr.method_5667();
                server.execute(() -> {
                    class_3218 sw = server.method_3847(c.field_1687.method_27983());
                    if (sw == null) return;
                    class_1297 se = sw.method_14190(id);
                    if (se != null) se.method_18799(nv);
                });
            }
        }
    }

    private void spawnDrones(class_310 c) {
        drones.clear();
        class_243 base = c.field_1724.method_33571();
        for (int i = 0; i < MAX_DRONES; i++) {
            double a = i * (Math.PI * 2 / MAX_DRONES);
            drones.add(new Drone(base.method_1031(Math.cos(a) * 2.0, 0.6, Math.sin(a) * 2.0), i));
        }
    }

    private void toggleDrones(class_310 c) {
        if (c.field_1724 == null || !shadesOn(c)) return;
        if (drones.isEmpty()) spawnDrones(c); else drones.clear();
    }

    private void tickDrones(class_310 c) {
        if (drones.isEmpty()) return;
        class_746 p = c.field_1724;
        class_638 w = c.field_1687;
        boolean ult = ultTimer > 0;
        class_243 sat = p.method_33571().method_1031(0, ULT_HEIGHT, 0);
        double step = Math.PI * 2 / MAX_DRONES;
        for (Drone d : drones) {
            class_243 goalPos;
            if (ult) {                                   // orbit the satellite in a fast ring
                double a = d.idx * step + p.field_6012 * 0.25;
                goalPos = sat.method_1031(Math.cos(a) * 5.0, 0, Math.sin(a) * 5.0);
            } else if (d.goal != null) {                 // commanded position (spread around it)
                double a = d.idx * step;
                goalPos = d.goal.method_1031(Math.cos(a) * 1.8, 1.0, Math.sin(a) * 1.8);
            } else {                                     // slow orbit around the player
                double a = d.idx * step + p.field_6012 * 0.02;
                goalPos = p.method_33571().method_1031(Math.cos(a) * 2.4, 0.7, Math.sin(a) * 2.4);
            }
            d.pos = d.pos.method_1019(goalPos.method_1020(d.pos).method_1021(ult ? 0.25 : 0.15));

            for (Drone o : drones) {
                if (o == d) continue;
                class_243 diff = d.pos.method_1020(o.pos);
                double dist = diff.method_1033();
                if (dist < 2.0 && dist > 0.0001)
                    d.pos = d.pos.method_1019(diff.method_1029().method_1021((2.0 - dist) * 0.5));
            }

            if ((p.field_6012 % 6) == 0)
                w.method_8406(class_2398.field_22246, d.pos.field_1352, d.pos.field_1351 - 0.35, d.pos.field_1350, 0, -0.01, 0);

            if (!ult) {   // normal: laser nearest hostile (ult handles its own damage)
                class_238 b = new class_238(d.pos.method_1023(DRONE_RANGE, DRONE_RANGE, DRONE_RANGE),
                                d.pos.method_1031(DRONE_RANGE, DRONE_RANGE, DRONE_RANGE));
                List<class_1308> near = w.method_8390(class_1308.class, b,
                    e -> e.method_5805() && (e instanceof class_1588));
                class_1308 t = near.stream()
                    .min(Comparator.comparingDouble(e -> e.method_5649(d.pos.field_1352, d.pos.field_1351, d.pos.field_1350)))
                    .orElse(null);
                if (d.cd > 0) d.cd--;
                if (t != null && d.cd <= 0) {
                    fireLaser(w, d.pos, t.method_33571());
                    damage(c, t, DRONE_DMG);
                    d.cd = 12;
                }
            }
        }
    }

    // ULTIMATE: orbital-strike satellite obliterates all creatures for 10s.
    private void tickUltimate(class_310 c) {
        class_746 p = c.field_1724;
        class_638 w = c.field_1687;
        class_243 sat = p.method_33571().method_1031(0, ULT_HEIGHT, 0);
        // vertical beam column
        for (int i = 0; i < 30; i++) {
            double yy = sat.field_1351 - i * 0.6;
            w.method_8406(class_2398.field_11207,
                p.method_23317() + (Math.random() - 0.5) * 0.6, yy, p.method_23321() + (Math.random() - 0.5) * 0.6, 0, 0, 0);
        }
        List<class_1308> mobs = w.method_8390(class_1308.class,
            p.method_5829().method_1014(ULT_RADIUS), e -> e.method_5805());
        for (class_1308 m : mobs) {
            if ((p.field_6012 % 2) == 0) fireLaser(w, sat, m.method_5829().method_1005());
            if ((p.field_6012 % 4) == 0) damage(c, m, ULT_DMG);
        }
    }

    // DOMAIN EXPANSION — builds an enclosed machine dome; every hostile inside
    // is guaranteed-hit (sure-hit) and bound while it lasts.
    private void tickDomain(class_310 c) {
        class_746 p = c.field_1724;
        class_638 w = c.field_1687;
        if (domainCenter == null) domainCenter = p.method_19538();
        class_243 ctr = domainCenter;
        double R = DOMAIN_RADIUS;
        long t = p.field_6012;
        int elapsed = DOMAIN_TICKS - domainTimer;
        double form = Math.min(1.0, elapsed / 12.0);   // 0..1 barrier-forming sweep
        double spin = t * 0.05;

        // vertical ribs (meridians) — the dome cage
        int MER = 10, SEG = 8;
        for (int m = 0; m < MER; m++) {
            double theta = m * (Math.PI * 2 / MER) + spin;
            for (int s = 0; s <= SEG; s++) {
                double elev = (Math.PI / 2) * s / SEG * form;
                double hr = R * Math.cos(elev);
                w.method_8406(class_2398.field_11207,
                    ctr.field_1352 + Math.cos(theta) * hr, ctr.field_1351 + R * Math.sin(elev), ctr.field_1350 + Math.sin(theta) * hr, 0, 0, 0);
            }
        }
        // horizontal latitude rings (every other tick)
        if ((t & 1) == 0) {
            int LAT = 3;
            for (int l = 1; l <= LAT; l++) {
                double elev = (Math.PI / 2) * l / (LAT + 1) * form;
                double hr = R * Math.cos(elev);
                double y = ctr.field_1351 + R * Math.sin(elev);
                for (int s = 0; s < 24; s++) {
                    double a = s * (Math.PI * 2 / 24) - spin * 0.6;
                    w.method_8406(class_2398.field_22246, ctr.field_1352 + Math.cos(a) * hr, y, ctr.field_1350 + Math.sin(a) * hr, 0, 0, 0);
                }
            }
            // floor circuit-grid rings
            for (int rr = 1; rr <= 3; rr++) {
                double rad = R * rr / 3.0 * form;
                for (int s = 0; s < 24; s++) {
                    double a = s * (Math.PI * 2 / 24) + spin * 0.4;
                    w.method_8406(class_2398.field_29644, ctr.field_1352 + Math.cos(a) * rad, ctr.field_1351 + 0.05, ctr.field_1350 + Math.sin(a) * rad, 0, 0, 0);
                }
            }
        }

        // ===== mystical layer: light pillar, rune mandala, glyphs, sky halo =====
        // central light pillar rising to the heavens
        for (int i = 0; i < 22; i++) {
            double yy = ctr.field_1351 + i * 1.15 * form;
            double jj = (Math.random() - 0.5) * 0.4;
            w.method_8406(class_2398.field_11207, ctr.field_1352 + jj, yy, ctr.field_1350 + jj, 0, 0.02, 0);
        }
        w.method_8406(class_2398.field_11248, ctr.field_1352, ctr.field_1351 + 1 + Math.random() * 20 * form, ctr.field_1350, 0, 0.04, 0);
        // arcane glyphs swirling around the core
        double gspin = t * 0.04;
        for (int i = 0; i < 10; i++) {
            double a = i * (Math.PI * 2 / 10) + gspin;
            double gy = ctr.field_1351 + 3 + (i % 5) * 2.2;
            w.method_8406(class_2398.field_11215, ctr.field_1352 + Math.cos(a) * R * 0.4, gy, ctr.field_1350 + Math.sin(a) * R * 0.4, 0, 0, 0);
            w.method_8406(class_2398.field_11214, ctr.field_1352 + Math.cos(-a) * R * 0.55, gy - 1, ctr.field_1350 + Math.sin(-a) * R * 0.55, 0, 0, 0);
        }
        if ((t & 1) == 0) {
            double mspin = t * 0.02;
            // big rotating rune mandala on the ground
            for (int rr = 4; rr <= 6; rr++) {
                double rad = R * rr / 6.0 * form;
                for (int s = 0; s < 24; s++) {
                    double a = s * (Math.PI * 2 / 24) - mspin;
                    w.method_8406(class_2398.field_22246, ctr.field_1352 + Math.cos(a) * rad, ctr.field_1351 + 0.04, ctr.field_1350 + Math.sin(a) * rad, 0, 0, 0);
                }
            }
            for (int s = 0; s < 8; s++) {
                double a = s * (Math.PI / 4) + mspin;
                for (double d2 = 1.5; d2 < R * form; d2 += 1.7)
                    w.method_8406(class_2398.field_29644, ctr.field_1352 + Math.cos(a) * d2, ctr.field_1351 + 0.04, ctr.field_1350 + Math.sin(a) * d2, 0, 0, 0);
            }
            // sky halo ring high above
            double hy = ctr.field_1351 + 22 * form, hr = R * 1.1;
            for (int s = 0; s < 40; s++) {
                double a = s * (Math.PI * 2 / 40) + spin * 0.3;
                w.method_8406(class_2398.field_11207, ctr.field_1352 + Math.cos(a) * hr, hy, ctr.field_1350 + Math.sin(a) * hr, 0, 0, 0);
            }
        }
        // low violet mist for mystery
        if ((t % 3) == 0)
            for (int i = 0; i < 6; i++) {
                double a = Math.random() * Math.PI * 2, d2 = Math.random() * R * form;
                w.method_8406(class_2398.field_11216, ctr.field_1352 + Math.cos(a) * d2, ctr.field_1351 + 0.1, ctr.field_1350 + Math.sin(a) * d2, 0, 0.004, 0);
            }

        // FREEZE: lock every creature/player (but the caster) in place within 20 chunks
        freezeField(c);

        // SURE-HIT: bind + damage every hostile trapped inside the domain
        class_238 box = new class_238(ctr.method_1023(R, R, R), ctr.method_1031(R, R, R));
        List<class_1308> mobs = w.method_8390(class_1308.class, box,
            e -> e.method_5805() && (e instanceof class_1588) && e.method_19538().method_1022(ctr) <= R + 1.0);
        class_243 apex = ctr.method_1031(0, R, 0);
        for (class_1308 m : mobs) {
            class_243 mc2 = m.method_5829().method_1005();
            if ((t % 4) == 0) fireLaser(w, apex, mc2);
            if ((t % 3) == 0) domainHit(c, m, DOMAIN_DMG);
            w.method_8406(class_2398.field_29644, mc2.field_1352, mc2.field_1351, mc2.field_1350, 0, 0, 0);
        }
    }

    // Freeze all living entities (and other players) except the caster, in a 20-chunk
    // radius: each is held at its captured lock position. Runs on the integrated server.
    private void freezeField(class_310 c) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576();
        if (server == null || domainCenter == null) return;
        UUID casterId = c.field_1724.method_5667();
        class_243 ctr = domainCenter;
        double R = FREEZE_RADIUS;
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983());
            if (sw == null) return;
            class_238 b = new class_238(ctr.method_1023(R, R, R), ctr.method_1031(R, R, R));
            for (class_1297 e : sw.method_8335(null, b)) {
                if (!(e instanceof class_1309)) continue;
                if (e.method_5667().equals(casterId)) continue;
                class_243 lock = frozen.computeIfAbsent(e.method_5667(), k -> e.method_19538());
                e.method_18800(0, 0, 0);
                e.field_6017 = 0;
                if (e instanceof net.minecraft.class_3222 sp)
                    sp.method_5859(lock.field_1352, lock.field_1351, lock.field_1350);   // forces the client to hold
                else
                    e.method_5814(lock.field_1352, lock.field_1351, lock.field_1350);        // snaps mobs back each tick
            }
        });
    }

    // Domain sure-hit: real damage + bind (slowness/weakness) in singleplayer.
    private void domainHit(class_310 c, class_1308 mob, float amt) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576();
        if (server == null) return;
        UUID id = mob.method_5667();
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983());
            if (sw == null) return;
            class_1297 se = sw.method_14190(id);
            if (se instanceof class_1309 le) {
                le.method_64397(sw, sw.method_48963().method_48831(), amt);
                le.method_6092(new class_1293(class_1294.field_5909, 30, 4));
                le.method_6092(new class_1293(class_1294.field_5911, 30, 2));
            }
        });
    }

    // =====================================================================
    //  CROW FAN KIT — 세계 / 까마귀 소환 / 까마귀의 날개 / 망자 봉인
    // =====================================================================
    private void tickCrowKit(class_310 c) {
        boolean held = heldFan(c);
        long win = c.method_22683().method_4490();
        boolean ns = c.field_1755 == null;
        boolean rNow = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_R);
        boolean cNow = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_C);
        boolean vNow = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_V);
        boolean xNow = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_X);
        if (rNow && !lastR && crowDomainTimer <= 0) { crowDomainTimer = CROW_DOMAIN_TICKS; crowCenter = c.field_1724.method_19538(); }
        if (cNow && !lastC && arenaTimer <= 0) summonCrows(c);   // no summons inside the arena
        if (vNow && !lastV && wingsTimer <= 0) activateWings(c);
        if (xNow && !lastX && sealTimer <= 0) startSeal(c);
        lastR = rNow; lastC = cNow; lastV = vNow; lastX = xNow;

        if (!held) crows.clear();                       // crows are bound to the fan
        if (crowDomainTimer > 0) { tickCrowDomain(c); crowDomainTimer--; }
        if (wingsTimer > 0) { tickWings(c); wingsTimer--; }
        if (sealTimer > 0) { tickSeal(c); sealTimer--; }
        if (!crows.isEmpty()) tickCrows(c);
    }

    // ---- 까마귀 소환 (summon a murder of crows that hunt for you) ----
    private void summonCrows(class_310 c) {
        crows.clear();
        class_243 base = c.field_1724.method_33571();
        for (int i = 0; i < MAX_CROWS; i++) {
            double a = i * (Math.PI * 2 / MAX_CROWS);
            crows.add(new Crow(base.method_1031(Math.cos(a) * 3.0, 1.5 + Math.sin(i) * 0.5, Math.sin(a) * 3.0), i));
        }
    }

    private void tickCrows(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687; long t = p.field_6012;
        double step = Math.PI * 2 / Math.max(1, crows.size());
        List<class_1308> host = w.method_8390(class_1308.class, p.method_5829().method_1014(CROW_ATTACK_RANGE),
            e -> e.method_5805() && (e instanceof class_1588));
        for (Crow cw : crows) {
            class_1308 tgt = host.stream()
                .min(Comparator.comparingDouble(e -> e.method_5649(cw.pos.field_1352, cw.pos.field_1351, cw.pos.field_1350))).orElse(null);
            class_243 goal;
            if (tgt != null) goal = tgt.method_5829().method_1005().method_1031(0, 0.3, 0);
            else { double a = cw.idx * step + t * 0.05;
                goal = p.method_33571().method_1031(Math.cos(a) * 3.2, 1.6 + Math.sin(t * 0.05 + cw.idx) * 0.4, Math.sin(a) * 3.2); }
            class_243 prev = cw.pos;
            cw.pos = cw.pos.method_1019(goal.method_1020(cw.pos).method_1021(0.2));
            double mvx = cw.pos.field_1352 - prev.field_1352, mvz = cw.pos.field_1350 - prev.field_1350;
            if (mvx * mvx + mvz * mvz > 1e-4) cw.face = Math.toDegrees(Math.atan2(-mvx, mvz));
            if ((t % 4) == 0) w.method_8406(class_2398.field_11251, cw.pos.field_1352, cw.pos.field_1351 - 0.2, cw.pos.field_1350, 0, 0, 0);
            if (cw.cd > 0) cw.cd--;
            if (tgt != null && cw.pos.method_1022(tgt.method_5829().method_1005()) < 2.2 && cw.cd <= 0) {
                crowHit(c, tgt, CROW_PECK_DMG); cw.cd = 10;
                class_243 tc = tgt.method_5829().method_1005();
                for (int k = 0; k < 5; k++) w.method_8406(class_2398.field_11205, tc.field_1352, tc.field_1351, tc.field_1350, 0, 0, 0);
            }
        }
    }

    // ---- 까마귀의 날개 (a leaping glide on crow wings) ----
    private void activateWings(class_310 c) {
        wingsTimer = WINGS_TICKS;
        c.field_1724.method_18800(c.field_1724.method_18798().field_1352, 1.15, c.field_1724.method_18798().field_1350);
        playerEffect(c, class_1294.field_5906, WINGS_TICKS, 0);
        playerEffect(c, class_1294.field_5904, WINGS_TICKS, 1);
        playerEffect(c, class_1294.field_5913, WINGS_TICKS, 2);
        for (int i = 0; i < 22; i++)
            c.field_1687.method_8406(class_2398.field_11251, c.field_1724.method_23317() + (Math.random() - 0.5) * 1.6,
                c.field_1724.method_23318() + 1.0 + (Math.random() - 0.5), c.field_1724.method_23321() + (Math.random() - 0.5) * 1.6, 0, 0, 0);
    }

    private void tickWings(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687;
        class_243 back = p.method_5828(1.0f).method_1021(-0.6);
        for (int i = 0; i < 3; i++) {
            double sx = (Math.random() - 0.5) * 1.4, sy = (Math.random() - 0.5) * 1.0;
            w.method_8406(class_2398.field_11251, p.method_23317() + back.field_1352 + sx, p.method_23318() + 1.0 + sy, p.method_23321() + back.field_1350 + sx, 0, 0, 0);
        }
        w.method_8406(class_2398.field_22246, p.method_23317() + back.field_1352, p.method_23318() + 1.2, p.method_23321() + back.field_1350, 0, 0.01, 0);
    }

    // ---- 망자 봉인 (a sealing sigil that roots and withers the dead) ----
    private void startSeal(class_310 c) {
        sealTimer = SEAL_TICKS;
        class_243 look = c.field_1724.method_5828(1.0f);
        class_243 flat = new class_243(look.field_1352, 0, look.field_1350);
        if (flat.method_1027() < 1e-4) flat = new class_243(0, 0, 1);
        flat = flat.method_1029();
        sealCenter = c.field_1724.method_19538().method_1019(flat.method_1021(5.0)).method_1031(0, 0.1, 0);
    }

    private void tickSeal(class_310 c) {
        if (sealCenter == null) return;
        class_638 w = c.field_1687; long t = c.field_1724.field_6012; class_243 s = sealCenter;
        int el = SEAL_TICKS - sealTimer; double gr = Math.min(1.0, el / 8.0) * 5.0; double sp = t * 0.15;
        for (int rr = 1; rr <= 3; rr++) {
            double rad = gr * rr / 3.0; int seg = 28;
            for (int i = 0; i < seg; i++) {
                double a = i * (Math.PI * 2 / seg) + (rr % 2 == 0 ? -sp : sp);
                w.method_8406(rr == 2 ? class_2398.field_22246 : class_2398.field_11216,
                    s.field_1352 + Math.cos(a) * rad, s.field_1351 + 0.05, s.field_1350 + Math.sin(a) * rad, 0, 0, 0);
            }
        }
        for (int i = 0; i < 5; i++) {
            double a = i * (Math.PI * 2 / 5) + t * 0.02;
            for (double d2 = 0.5; d2 < gr; d2 += 0.8)
                w.method_8406(class_2398.field_23114, s.field_1352 + Math.cos(a) * d2, s.field_1351 + 0.05, s.field_1350 + Math.sin(a) * d2, 0, 0, 0);
        }
        class_238 b = new class_238(s.method_1023(5.5, 3, 5.5), s.method_1031(5.5, 4, 5.5));
        List<class_1308> mobs = w.method_8390(class_1308.class, b,
            e -> e.method_5805() && (e instanceof class_1588) && e.method_19538().method_1022(s) <= 6.0);
        for (class_1308 m : mobs) {
            if ((t % 3) == 0) crowHit(c, m, 9.0f);
            sealBind(c, m);
            class_243 mc2 = m.method_5829().method_1005();
            w.method_8406(class_2398.field_22246, mc2.field_1352, mc2.field_1351, mc2.field_1350, 0, 0.03, 0);
        }
    }

    // ---- 까마귀들의 무덤 domain: poison everything, drape the world in ash ----
    private void tickCrowDomain(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687;
        if (crowCenter == null) crowCenter = p.method_19538();
        class_243 ctr = crowCenter; double R = CROW_RADIUS; long t = p.field_6012;
        int elapsed = CROW_DOMAIN_TICKS - crowDomainTimer; double form = Math.min(1.0, elapsed / 16.0);
        double spin = t * 0.03;
        int MER = 12, SEG = 9;
        for (int m = 0; m < MER; m++) {
            double th = m * (Math.PI * 2 / MER) + spin;
            for (int sgi = 0; sgi <= SEG; sgi++) {
                double elev = (Math.PI / 2) * sgi / SEG * form; double hr = R * Math.cos(elev);
                w.method_8406(class_2398.field_22246,
                    ctr.field_1352 + Math.cos(th) * hr, ctr.field_1351 + R * Math.sin(elev), ctr.field_1350 + Math.sin(th) * hr, 0, 0, 0);
            }
        }
        if ((t & 1) == 0) {
            for (int rr = 1; rr <= 4; rr++) {
                double rad = R * rr / 4.0 * form; int seg = 30;
                for (int sgi = 0; sgi < seg; sgi++) {
                    double a = sgi * (Math.PI * 2 / seg) + spin * 0.3;
                    w.method_8406(class_2398.field_11237, ctr.field_1352 + Math.cos(a) * rad, ctr.field_1351 + 0.1, ctr.field_1350 + Math.sin(a) * rad, 0, 0.01, 0);
                    if ((sgi % 3) == 0)
                        w.method_8406(class_2398.field_11211, ctr.field_1352 + Math.cos(a) * rad, ctr.field_1351 + 0.3 + Math.random() * 0.6, ctr.field_1350 + Math.sin(a) * rad, 0, 0, 0);
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            double a = Math.random() * Math.PI * 2, d2 = Math.random() * R * form;
            w.method_8406(class_2398.field_22247, ctr.field_1352 + Math.cos(a) * d2, ctr.field_1351 + 8 + Math.random() * 10, ctr.field_1350 + Math.sin(a) * d2, 0, -0.02, 0);
        }
        // BLOOD RAIN — dark red drops falling across the whole grave
        class_2390 blood = new class_2390(0x8A0303, 1.4f);
        for (int i = 0; i < 14; i++) {
            double a = Math.random() * Math.PI * 2, d2 = Math.random() * R * form;
            w.method_8406(blood, ctr.field_1352 + Math.cos(a) * d2, ctr.field_1351 + 4 + Math.random() * 14, ctr.field_1350 + Math.sin(a) * d2, 0, -0.35, 0);
        }
        class_238 box = new class_238(ctr.method_1023(R, R, R), ctr.method_1031(R, R, R));
        List<class_1308> mobs = w.method_8390(class_1308.class, box,
            e -> e.method_5805() && (e instanceof class_1588) && e.method_19538().method_1022(ctr) <= R + 1.0);
        for (class_1308 m : mobs) {
            class_243 mc2 = m.method_5829().method_1005();
            if ((t % 2) == 0) w.method_8406(class_2398.field_23114, mc2.field_1352, mc2.field_1351, mc2.field_1350, 0, 0.02, 0);
            if ((t % 4) == 0) crowHit(c, m, CROW_DMG);
        }
    }

    // server-side effect helpers
    private void crowHit(class_310 c, class_1308 mob, float amt) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = mob.method_5667();
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983()); if (sw == null) return;
            class_1297 se = sw.method_14190(id);
            if (se instanceof class_1309 le) {
                le.method_64397(sw, sw.method_48963().method_48831(), amt);
                le.method_6092(new class_1293(class_1294.field_5899, 80, 2));
                le.method_6092(new class_1293(class_1294.field_5920, 60, 0));
                le.method_6092(new class_1293(class_1294.field_5909, 40, 2));
            }
        });
    }
    private void sealBind(class_310 c, class_1308 mob) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = mob.method_5667();
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983()); if (sw == null) return;
            class_1297 se = sw.method_14190(id);
            if (se instanceof class_1309 le) {
                le.method_18800(0, 0, 0);
                le.method_6092(new class_1293(class_1294.field_5909, 20, 6));
                le.method_6092(new class_1293(class_1294.field_5920, 40, 1));
            }
        });
    }
    private void playerEffect(class_310 c, class_6880<class_1291> eff, int dur, int amp) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = c.field_1724.method_5667();
        server.execute(() -> {
            var sp = server.method_3760().method_14602(id);
            if (sp != null) sp.method_6092(new class_1293(eff, dur, amp));
        });
    }

    // Render the crow-grave structures around the domain center.
    private void renderCrowWorld(class_4587 ms, class_4597 vcp, class_310 mc, class_243 camPos, int light) {
        class_243 ctr = crowCenter; float age = mc.field_1724.field_6012;
        int elapsed = CROW_DOMAIN_TICKS - crowDomainTimer; float rise = Math.min(1f, elapsed / 18f);
        // central grand monument
        float mScale = 3.2f * (0.25f + 0.75f * rise);
        double mLift = (22.3 * 0.852 / 16.0) * mScale;
        renderModel(MONU_STACK, ms, vcp, mc, camPos, light, ctr.field_1352, ctr.field_1351 + mLift, ctr.field_1350, mScale, age * 0.4f, 0f, false);
        // torii gates at 4 cardinals
        for (int i = 0; i < 4; i++) {
            double a = i * (Math.PI / 2) + Math.PI / 4;
            float sc = 2.4f * (0.3f + 0.7f * rise);
            double lift = (13.15 / 16.0) * sc;
            double tx = ctr.field_1352 + Math.cos(a) * CROW_RADIUS * 0.82, tz = ctr.field_1350 + Math.sin(a) * CROW_RADIUS * 0.82;
            renderModel(TORII_STACK, ms, vcp, mc, camPos, light, tx, ctr.field_1351 + lift, tz, sc, (float) Math.toDegrees(a) + 90, 0f, false);
        }
        // tombstones ringing the grave
        int TN = 10;
        for (int i = 0; i < TN; i++) {
            double a = i * (Math.PI * 2 / TN) + 0.3;
            float sc = 2.0f * (0.3f + 0.7f * rise);
            double lift = (9.8 / 16.0) * sc;
            double tx = ctr.field_1352 + Math.cos(a) * CROW_RADIUS * 0.5, tz = ctr.field_1350 + Math.sin(a) * CROW_RADIUS * 0.5;
            renderModel(TOMB_STACK, ms, vcp, mc, camPos, light, tx, ctr.field_1351 + lift, tz, sc, (float) Math.toDegrees(a) + 180, 0f, false);
        }
        // gnarled dead trees
        int DT = 6;
        for (int i = 0; i < DT; i++) {
            double a = i * (Math.PI * 2 / DT) + 0.9;
            float sc = 2.6f * (0.3f + 0.7f * rise);
            double lift = (17.2 / 16.0) * sc;
            double tx = ctr.field_1352 + Math.cos(a) * CROW_RADIUS * 0.66, tz = ctr.field_1350 + Math.sin(a) * CROW_RADIUS * 0.66;
            renderModel(TREE_STACK, ms, vcp, mc, camPos, light, tx, ctr.field_1351 + lift, tz, sc, (float) (i * 57 % 360), 0f, false);
        }
        // gallows with hanging cages (gruesome)
        int GN = 4;
        for (int i = 0; i < GN; i++) {
            double a = i * (Math.PI * 2 / GN) + 0.15;
            float sc = 2.2f * (0.3f + 0.7f * rise);
            double lift = (16.0 / 16.0) * sc;
            double gx = ctr.field_1352 + Math.cos(a) * CROW_RADIUS * 0.72, gz = ctr.field_1350 + Math.sin(a) * CROW_RADIUS * 0.72;
            renderModel(GALLOWS_STACK, ms, vcp, mc, camPos, light, gx, ctr.field_1351 + lift, gz, sc, (float) Math.toDegrees(a) + 90, 0f, false);
        }
        // impaled skull spikes
        int SN = 6;
        for (int i = 0; i < SN; i++) {
            double a = i * (Math.PI * 2 / SN) + 0.55;
            float sc = 1.9f * (0.3f + 0.7f * rise);
            double lift = (14.0 / 16.0) * sc;
            double sx = ctr.field_1352 + Math.cos(a) * CROW_RADIUS * 0.38, sz = ctr.field_1350 + Math.sin(a) * CROW_RADIUS * 0.38;
            renderModel(SPIKE_STACK, ms, vcp, mc, camPos, light, sx, ctr.field_1351 + lift, sz, sc, (float) (i * 63 % 360), 0f, false);
        }
        // ambient crows wheeling overhead
        int AC = 6;
        for (int i = 0; i < AC; i++) {
            double a = i * (Math.PI * 2 / AC) + age * 0.02;
            double rad = CROW_RADIUS * 0.55;
            double cx = ctr.field_1352 + Math.cos(a) * rad, cz = ctr.field_1350 + Math.sin(a) * rad;
            double cy = ctr.field_1351 + 12 + (i % 3) * 3 + Math.sin(age * 0.03 + i) * 1.2;
            renderModel(CROW_STACK, ms, vcp, mc, camPos, light, cx, cy, cz, 1.1f,
                (float) Math.toDegrees(a) + 90, 0f, false);
        }
    }

    // =====================================================================
    //  DUEL ARENA — 전사들의 결투장 : lock the nearest foe in, expel the rest
    // =====================================================================
    private void tickArenaKit(class_310 c) {
        boolean held = heldSword(c);
        long win = c.method_22683().method_4490();
        boolean ns = c.field_1755 == null;
        boolean bNow = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_B);
        boolean zNow = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_Z);
        boolean nNow = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_N);
        if (bNow && !lastB && arenaTimer <= 0) startArena(c);
        if (zNow && !lastZ && berserkTimer <= 0) startBerserk(c);
        if (nNow && !lastN && slashTimer <= 0) bloodSlash(c);
        lastB = bNow; lastZ = zNow; lastN = nNow;
        if (arenaTimer > 0) {
            tickArena(c);
            if (arenaTimer > 0) { arenaTimer--; if (arenaTimer == 0) endArena(); }
        }
        if (berserkTimer > 0) { tickBerserk(c); berserkTimer--; }
        if (slashTimer > 0) { tickSlash(c); slashTimer--; }
        if (judgmentTimer > 0) { tickJudgment(c); judgmentTimer--; }
    }

    private void startArena(class_310 c) {
        arenaCenter = c.field_1724.method_19538();
        arenaTimer = ARENA_TICKS;
        judgmentDone = false;
        drones.clear(); crows.clear();          // existing summons are banished
        opponentId = pickOpponent(c);
        buffCaster(c);
        costHealthFraction(c, 0.15f);           // the caster pays 15% of their blood
    }
    private void costHealthFraction(class_310 c, float frac) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = c.field_1724.method_5667();
        server.execute(() -> {
            var sp = server.method_3760().method_14602(id);
            if (sp != null) sp.method_6033(Math.max(1.0f, sp.method_6032() - sp.method_6063() * frac));
        });
    }
    private void endArena() {
        arenaTimer = 0; opponentId = null; opponentEntity = null;
    }

    private UUID pickOpponent(class_310 c) {
        class_243 ctr = arenaCenter;
        List<class_1309> near = c.field_1687.method_8390(class_1309.class,
            new class_238(ctr.method_1023(24, 24, 24), ctr.method_1031(24, 24, 24)), e -> e.method_5805() && e != c.field_1724);
        class_1309 best = null; double bd = 1e9;
        for (class_1309 e : near) if (e instanceof class_1657) { double d = e.method_5858(c.field_1724); if (d < bd) { bd = d; best = e; } }
        if (best == null) { bd = 1e9; for (class_1309 e : near) { double d = e.method_5858(c.field_1724); if (d < bd) { bd = d; best = e; } } }
        opponentEntity = best;
        if (best != null) { opponentName = best.method_5477().getString(); return best.method_5667(); }
        opponentName = "—"; return null;
    }

    private void buffCaster(class_310 c) {
        playerEffect(c, class_1294.field_5910, 90, 1);
        playerEffect(c, class_1294.field_5904, 90, 1);
        playerEffect(c, class_1294.field_5917, 90, 1);
        playerEffect(c, class_1294.field_5907, 90, 0);
    }

    private void tickArena(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687;
        class_243 ctr = arenaCenter; double R = ARENA_RADIUS; long t = p.field_6012;
        int elapsed = ARENA_TICKS - arenaTimer; double form = Math.min(1.0, elapsed / 16.0); double spin = t * 0.02;

        if (!renderingRemote) {
            // the duel ends the instant the chosen foe falls — only then may anyone leave
            if (elapsed > 6 && (opponentEntity == null || !opponentEntity.method_5805() || opponentEntity.method_31481())) {
                endArena(); return;
            }
            // the caster is bound inside too — an invisible wall holds them in the ring
            double pdx = p.method_23317() - ctr.field_1352, pdz = p.method_23321() - ctr.field_1350, pd = Math.sqrt(pdx * pdx + pdz * pdz);
            if (pd > R * 0.94 && pd > 0.01) {
                double f = R * 0.9 / pd;
                p.method_5814(ctr.field_1352 + pdx * f, p.method_23318(), ctr.field_1350 + pdz * f);
                class_243 v = p.method_18798(); p.method_18800(v.field_1352 * 0.1, v.field_1351, v.field_1350 * 0.1);
            }
        }
        // glowing boundary wall of flame (rising as the arena forms)
        int seg = 60;
        for (int s = 0; s < seg; s++) {
            double a = s * (Math.PI * 2 / seg) + spin;
            double x = ctr.field_1352 + Math.cos(a) * R, z = ctr.field_1350 + Math.sin(a) * R;
            for (int h = 0; h < 3; h++)
                if (((s + h) & 1) == 0) w.method_8406(class_2398.field_11240, x, ctr.field_1351 + 0.2 + h * 1.4 * form, z, 0, 0.01, 0);
        }
        // radiant ground rings
        if ((t & 1) == 0)
            for (int rr = 1; rr <= 3; rr++) {
                double rad = R * rr / 3.0 * form; int sg = 40;
                for (int s = 0; s < sg; s++) {
                    double a = s * (Math.PI * 2 / sg) - spin * 0.5;
                    w.method_8406(class_2398.field_11207, ctr.field_1352 + Math.cos(a) * rad, ctr.field_1351 + 0.05, ctr.field_1350 + Math.sin(a) * rad, 0, 0, 0);
                }
            }
        if ((t % 40) == 0) buffCaster(c);
        arenaField(c);

        // 전사의 심판 — if the foe wields a ranged weapon, the God-Warrior's hand judges them
        if (!judgmentDone && opponentEntity != null && opponentEntity.method_5805() && isRanged(opponentEntity)) {
            judgmentDone = true;
            judgmentTimer = JUDGE_TICKS;
            judgmentPos = opponentEntity.method_19538();
            instakillOpponent(c);
        }
    }

    private boolean isRanged(class_1309 e) {
        class_1799 m = e.method_6047(), o = e.method_6079();
        return m.method_31574(class_1802.field_8102) || m.method_31574(class_1802.field_8399) || m.method_31574(class_1802.field_8547)
            || o.method_31574(class_1802.field_8102) || o.method_31574(class_1802.field_8399) || o.method_31574(class_1802.field_8547);
    }

    // server side: keep the chosen foe in & weakened, hurl everyone else out
    private void arenaField(class_310 c) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null || arenaCenter == null) return;
        UUID casterId = c.field_1724.method_5667(); UUID oppId = opponentId; class_243 ctr = arenaCenter; double R = ARENA_RADIUS;
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983()); if (sw == null) return;
            class_238 b = new class_238(ctr.method_1023(R + 30, 64, R + 30), ctr.method_1031(R + 30, 64, R + 30));
            for (class_1297 e : sw.method_8335(null, b)) {
                if (!(e instanceof class_1309 le)) continue;
                UUID id = e.method_5667();
                if (id.equals(casterId)) continue;
                double dx = e.method_23317() - ctr.field_1352, dz = e.method_23321() - ctr.field_1350, d = Math.sqrt(dx * dx + dz * dz);
                double ux = d < 0.01 ? 1 : dx / d, uz = d < 0.01 ? 0 : dz / d;
                if (oppId != null && id.equals(oppId)) {
                    if (d > R * 0.9) {   // keep the duelist inside the ring
                        double tx = ctr.field_1352 + ux * R * 0.8, tz = ctr.field_1350 + uz * R * 0.8;
                        if (le instanceof net.minecraft.class_3222 sp) sp.method_5859(tx, e.method_23318(), tz);
                        else le.method_5814(tx, e.method_23318(), tz);
                    }
                    le.method_6092(new class_1293(class_1294.field_5911, 45, 1));
                    le.method_6092(new class_1293(class_1294.field_5909, 45, 0));
                } else if (d < R + 2) {   // expel every other soul beyond the arena
                    double tx = ctr.field_1352 + ux * (R + 5), tz = ctr.field_1350 + uz * (R + 5);
                    if (le instanceof net.minecraft.class_3222 sp) sp.method_5859(tx, e.method_23318(), tz);
                    else le.method_5814(tx, e.method_23318(), tz);
                    le.method_18800(ux * 0.6, 0.25, uz * 0.6);
                }
            }
        });
    }

    private void renderArena(class_4587 ms, class_4597 vcp, class_310 mc, class_243 camPos, int light) {
        class_243 ctr = arenaCenter; float age = mc.field_1724.field_6012;
        int elapsed = ARENA_TICKS - arenaTimer; float rise = Math.min(1f, elapsed / 18f);
        int PN = 12; float ps = 2.2f * (0.3f + 0.7f * rise); double plift = (22.6 / 16.0) * ps;
        for (int i = 0; i < PN; i++) {
            double a = i * (Math.PI * 2 / PN) + 0.26;
            double px = ctr.field_1352 + Math.cos(a) * ARENA_RADIUS * 0.98, pz = ctr.field_1350 + Math.sin(a) * ARENA_RADIUS * 0.98;
            renderModel(PILLAR_STACK, ms, vcp, mc, camPos, light, px, ctr.field_1351 + plift, pz, ps, (float) Math.toDegrees(a) + 90, 0f, false);
        }
        int AN = 4; float as = 2.4f * (0.3f + 0.7f * rise); double alift = (18.5 / 16.0) * as;
        for (int i = 0; i < AN; i++) {
            double a = i * (Math.PI / 2);
            double ax = ctr.field_1352 + Math.cos(a) * ARENA_RADIUS * 1.04, az = ctr.field_1350 + Math.sin(a) * ARENA_RADIUS * 1.04;
            renderModel(ARCH_STACK, ms, vcp, mc, camPos, light, ax, ctr.field_1351 + alift, az, as, (float) Math.toDegrees(a) + 90, 0f, false);
        }
    }

    // ---- 광폭화 (Berserk) : frenzy self-buff ----
    private void startBerserk(class_310 c) {
        berserkTimer = BERSERK_TICKS;
        playerEffect(c, class_1294.field_5910, BERSERK_TICKS, 2);
        playerEffect(c, class_1294.field_5904, BERSERK_TICKS, 1);
        playerEffect(c, class_1294.field_5917, BERSERK_TICKS, 2);
        playerEffect(c, class_1294.field_5907, BERSERK_TICKS, 0);
        class_746 p = c.field_1724; class_638 w = c.field_1687;
        class_2390 red = new class_2390(0xC81020, 1.6f);
        for (int i = 0; i < 44; i++)
            w.method_8406(red, p.method_23317() + (Math.random() - 0.5) * 1.8, p.method_23318() + Math.random() * 2.2, p.method_23321() + (Math.random() - 0.5) * 1.8, 0, 0.02, 0);
    }
    private void tickBerserk(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687; long t = p.field_6012;
        if ((t % 40) == 0) {
            playerEffect(c, class_1294.field_5910, 60, 2);
            playerEffect(c, class_1294.field_5904, 60, 1);
            playerEffect(c, class_1294.field_5917, 60, 2);
        }
        class_2390 red = new class_2390(0xC81020, 1.4f);
        double a = t * 0.4;
        for (int i = 0; i < 3; i++) {
            double an = a + i * 2.1;
            w.method_8406(red, p.method_23317() + Math.cos(an) * 0.9, p.method_23318() + 0.2 + i * 0.6, p.method_23321() + Math.sin(an) * 0.9, 0, 0.01, 0);
        }
        if ((t % 3) == 0) w.method_8406(class_2398.field_11240, p.method_23317() + (Math.random() - 0.5), p.method_23318() + Math.random() * 2, p.method_23321() + (Math.random() - 0.5), 0, 0.01, 0);
    }

    // ---- 혈검술 (Blood Blade) : spend your own blood to hurl a devastating slash ----
    private void bloodSlash(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687;
        slashTimer = SLASH_TICKS;
        slashPos = p.method_33571(); slashDir = p.method_5828(1.0f);
        costHealth(c, 4.0f);                       // 2 hearts of your own blood
        class_243 eye = slashPos, look = slashDir;
        List<class_1308> mobs = w.method_8390(class_1308.class, p.method_5829().method_1014(11), e -> e.method_5805());
        for (class_1308 m : mobs) {
            class_243 to = m.method_5829().method_1005().method_1020(eye);
            if (to.method_1027() > 121) continue;
            if (to.method_1029().method_1026(look) < 0.55) continue;   // in the forward arc
            damage(c, m, SLASH_DMG);
        }
    }
    private void costHealth(class_310 c, float amt) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = c.field_1724.method_5667();
        server.execute(() -> {
            var sp = server.method_3760().method_14602(id);
            if (sp != null) sp.method_6033(Math.max(1.0f, sp.method_6032() - amt));
        });
    }
    private void tickSlash(class_310 c) {
        if (slashPos == null || slashDir == null) return; class_638 w = c.field_1687;
        int el = SLASH_TICKS - slashTimer; double travel = el * 1.1;
        class_243 center = slashPos.method_1019(slashDir.method_1021(travel));
        class_243 right = slashDir.method_1036(new class_243(0, 1, 0)).method_1029();
        class_243 u2 = right.method_1036(slashDir).method_1029();
        class_2390 blood = new class_2390(0xB00818, 1.8f);
        for (int i = -8; i <= 8; i++) {
            double a = i / 8.0 * (Math.PI * 0.6);
            class_243 off = right.method_1021(Math.sin(a) * 3.2).method_1019(u2.method_1021(Math.cos(a) * 3.2 - 3.2));
            class_243 pnt = center.method_1019(off);
            w.method_8406(blood, pnt.field_1352, pnt.field_1351, pnt.field_1350, 0, 0, 0);
            if ((i & 1) == 0) w.method_8406(class_2398.field_11205, pnt.field_1352, pnt.field_1351, pnt.field_1350, 0, 0, 0);
        }
    }

    // ---- 전사의 심판 : the God-Warrior's hand crushes a ranged coward ----
    private void instakillOpponent(class_310 c) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null || opponentId == null) return; UUID id = opponentId;
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983()); if (sw == null) return;
            class_1297 se = sw.method_14190(id);
            if (se instanceof class_1309 le) le.method_64397(sw, sw.method_48963().method_48831(), 100000f);
        });
    }
    private void tickJudgment(class_310 c) {
        if (judgmentPos == null) return; class_638 w = c.field_1687; class_243 pos = judgmentPos;
        for (int i = 0; i < 12; i++) {
            double a = Math.random() * Math.PI * 2, r = Math.random() * 4;
            w.method_8406(class_2398.field_11237, pos.field_1352 + Math.cos(a) * r, pos.field_1351 + 0.2, pos.field_1350 + Math.sin(a) * r, 0, 0.02, 0);
        }
        class_2390 blood = new class_2390(0xB00818, 2.0f);
        for (int i = 0; i < 8; i++)
            w.method_8406(blood, pos.field_1352 + (Math.random() - 0.5) * 2, pos.field_1351 + Math.random() * 3, pos.field_1350 + (Math.random() - 0.5) * 2, 0, 0, 0);
    }

    private boolean heldSword(class_310 c) {
        return c.field_1724 != null
            && (c.field_1724.method_6047().method_31574(VoidHunt.DUEL_SWORD)
             || c.field_1724.method_6079().method_31574(VoidHunt.DUEL_SWORD));
    }

    // ===== multiplayer: broadcast my visuals, paint everyone else's =====
    private void sendLocalFx(class_310 c) {
        if (c.field_1724 == null || !ClientPlayNetworking.canSend(VoidNet.PushC2S.ID)) return;
        VoidNet.Fx f = new VoidNet.Fx();
        if (domainTimer > 0)     { f.mCtr = domainCenter; f.mT = domainTimer; }
        if (crowDomainTimer > 0) { f.cCtr = crowCenter;   f.cT = crowDomainTimer; }
        if (arenaTimer > 0)      { f.aCtr = arenaCenter;  f.aT = arenaTimer; }
        f.uT = ultTimer; f.bT = berserkTimer;
        if (judgmentTimer > 0)   { f.jPos = judgmentPos;  f.jT = judgmentTimer; }
        if (seaTimer > 0)        { f.sCtr = seaCenter;    f.sT = seaTimer; }
        for (Drone d : drones) f.drones.add(d.pos);
        for (Crow cw : crows)  f.crows.add(cw.pos);
        for (Crow sk : sharks) f.sharks.add(sk.pos);
        if (f.anyActive()) ClientPlayNetworking.send(new VoidNet.PushC2S(f));
    }

    private void tickRemotes(class_310 c) {
        if (REMOTE.isEmpty() || c.field_1687 == null) return;
        var it = REMOTE.entrySet().iterator();
        while (it.hasNext()) {
            VoidNet.Fx f = it.next().getValue();
            f.age++;
            if (f.age > 8) { it.remove(); continue; }
            if (f.mT > 0) f.mT--; if (f.cT > 0) f.cT--; if (f.aT > 0) f.aT--;
            if (f.jT > 0) f.jT--; if (f.sT > 0) f.sT--;
            paintRemoteParticles(c, f);
        }
    }

    private void paintRemoteParticles(class_310 c, VoidNet.Fx f) {
        class_243 sm = domainCenter, sc = crowCenter, sa = arenaCenter, sj = judgmentPos, ss = seaCenter;
        int smt = domainTimer, sct = crowDomainTimer, sat = arenaTimer, sjt = judgmentTimer, sst = seaTimer;
        renderingRemote = true;
        try {
            if (f.mT > 0 && f.mCtr != null) { domainCenter = f.mCtr; domainTimer = f.mT; tickDomain(c); }
            if (f.cT > 0 && f.cCtr != null) { crowCenter = f.cCtr; crowDomainTimer = f.cT; tickCrowDomain(c); }
            if (f.aT > 0 && f.aCtr != null) { arenaCenter = f.aCtr; arenaTimer = f.aT; tickArena(c); }
            if (f.jT > 0 && f.jPos != null) { judgmentPos = f.jPos; judgmentTimer = f.jT; tickJudgment(c); }
            if (f.sT > 0 && f.sCtr != null) { seaCenter = f.sCtr; seaTimer = f.sT; tickSeaDomain(c); }
        } catch (Exception ignored) {}
        domainCenter = sm; crowCenter = sc; arenaCenter = sa; judgmentPos = sj; seaCenter = ss;
        domainTimer = smt; crowDomainTimer = sct; arenaTimer = sat; judgmentTimer = sjt; seaTimer = sst;
        renderingRemote = false;
    }

    private void renderRemote(UUID owner, VoidNet.Fx f, class_4587 ms, class_4597 vcp,
                             class_310 mc, class_243 camPos, int light) {
        class_243 sm = domainCenter, sc = crowCenter, sa = arenaCenter, ss = seaCenter;
        int smt = domainTimer, sct = crowDomainTimer, sat = arenaTimer, sst = seaTimer;
        renderingRemote = true;
        try {
            if (f.mT > 0 && f.mCtr != null) { domainCenter = f.mCtr; domainTimer = f.mT; renderDomain(ms, vcp, mc, camPos, light); }
            if (f.cT > 0 && f.cCtr != null) { crowCenter = f.cCtr; crowDomainTimer = f.cT; renderCrowWorld(ms, vcp, mc, camPos, light); }
            if (f.aT > 0 && f.aCtr != null) { arenaCenter = f.aCtr; arenaTimer = f.aT; renderArena(ms, vcp, mc, camPos, light); }
            if (f.sT > 0 && f.sCtr != null) { seaCenter = f.sCtr; seaTimer = f.sT; renderSeaWorld(ms, vcp, mc, camPos, light); }
            float spin = mc.field_1724.field_6012 * 2f;
            for (class_243 dp : f.drones) renderModel(DRONE_STACK, ms, vcp, mc, camPos, light, dp.field_1352, dp.field_1351, dp.field_1350, 0.8f, 0f, spin, false);
            for (class_243 cp : f.crows)  renderModel(CROW_STACK,  ms, vcp, mc, camPos, light, cp.field_1352, cp.field_1351, cp.field_1350, 0.9f, 0f, 0f, false);
            for (class_243 kp : f.sharks) renderModel(SHARK_STACK, ms, vcp, mc, camPos, light, kp.field_1352, kp.field_1351, kp.field_1350, 1.1f, 0f, 0f, false);
            if (f.uT > 0) {
                class_1657 op = findPlayer(mc, owner);
                if (op != null) { class_243 s = op.method_33571().method_1031(0, ULT_HEIGHT, 0);
                    renderModel(SAT_STACK, ms, vcp, mc, camPos, light, s.field_1352, s.field_1351, s.field_1350, 4.0f, 0f, mc.field_1724.field_6012 * 3f, false); }
            }
            if (f.jT > 0 && f.jPos != null) {
                int el = JUDGE_TICKS - f.jT; float prog = Math.min(1f, el / 22f);
                double startY = f.jPos.field_1351 + 30, curY = startY - (startY - (f.jPos.field_1351 + 2.5)) * prog;
                renderModel(HAND_STACK, ms, vcp, mc, camPos, light, f.jPos.field_1352, curY, f.jPos.field_1350, 6.0f, 0f, 0f, false);
            }
        } catch (Exception ignored) {}
        domainCenter = sm; crowCenter = sc; arenaCenter = sa; seaCenter = ss;
        domainTimer = smt; crowDomainTimer = sct; arenaTimer = sat; seaTimer = sst;
        renderingRemote = false;
    }

    private class_1657 findPlayer(class_310 mc, UUID id) {
        if (mc.field_1687 == null) return null;
        for (class_1657 pl : mc.field_1687.method_18456()) if (pl.method_5667().equals(id)) return pl;
        return null;
    }

    // =====================================================================
    //  OCEAN WORLD — 바다의 세계 / 해일 / 소용돌이 / 상어 떼
    // =====================================================================
    private boolean heldTrident(class_310 c) {
        return c.field_1724 != null
            && (c.field_1724.method_6047().method_31574(VoidHunt.SEA_TRIDENT)
             || c.field_1724.method_6079().method_31574(VoidHunt.SEA_TRIDENT));
    }

    private void tickSeaKit(class_310 c) {
        boolean held = heldTrident(c);
        long win = c.method_22683().method_4490();
        boolean ns = c.field_1755 == null;
        boolean jN = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_J);
        boolean uN = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_U);
        boolean yN = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_Y);
        boolean mN = held && ns && class_3675.method_15987(win, GLFW.GLFW_KEY_M);
        if (jN && !lastJ && seaTimer <= 0)  startSea(c);
        if (uN && !lastU && waveTimer <= 0) startWave(c);
        if (yN && !lastY && maelTimer <= 0) startMaelstrom(c);
        if (mN && !lastM) summonSharks(c);
        lastJ = jN; lastU = uN; lastY = yN; lastM = mN;
        if (!held) sharks.clear();
        if (seaTimer > 0)  { tickSeaDomain(c); seaTimer--; }
        if (waveTimer > 0) { tickWave(c); waveTimer--; }
        if (maelTimer > 0) { tickMaelstrom(c); maelTimer--; }
        if (!sharks.isEmpty()) tickSharks(c);
    }

    private void startSea(class_310 c) { seaCenter = c.field_1724.method_19538(); seaTimer = SEA_TICKS; buffSeaCaster(c); }
    private void buffSeaCaster(class_310 c) {
        playerEffect(c, class_1294.field_5923, 130, 0);
        playerEffect(c, class_1294.field_5900, 130, 1);
        playerEffect(c, class_1294.field_5927, 130, 0);
        playerEffect(c, class_1294.field_5910, 130, 0);
    }

    private void tickSeaDomain(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687;
        if (seaCenter == null) seaCenter = p.method_19538();
        class_243 ctr = seaCenter; double R = SEA_RADIUS; long t = p.field_6012;
        int elapsed = SEA_TICKS - seaTimer; double form = Math.min(1.0, elapsed / 16.0); double spin = t * 0.02;
        for (int i = 0; i < 16; i++) {
            double a = Math.random() * Math.PI * 2, d2 = Math.random() * R * form;
            w.method_8406(class_2398.field_11238, ctr.field_1352 + Math.cos(a) * d2, ctr.field_1351 + Math.random() * 2, ctr.field_1350 + Math.sin(a) * d2, 0, 0.1, 0);
        }
        class_2390 aqua = new class_2390(0x40E0E0, 1.5f);
        int MER = 12, SEG = 8;
        for (int m = 0; m < MER; m++) {
            double th = m * (Math.PI * 2 / MER) + spin;
            for (int s = 0; s <= SEG; s++) {
                double elev = (Math.PI / 2) * s / SEG * form; double hr = R * Math.cos(elev);
                w.method_8406(class_2398.field_11210, ctr.field_1352 + Math.cos(th) * hr, ctr.field_1351 + R * Math.sin(elev), ctr.field_1350 + Math.sin(th) * hr, 0, 0, 0);
            }
        }
        if ((t & 1) == 0) {
            for (int mm = 0; mm < 8; mm++) {            // descending god-rays
                double th = mm * (Math.PI * 2 / 8) + spin * 0.5; double hr = R * 0.7;
                for (int s = 0; s < 6; s++) w.method_8406(aqua, ctr.field_1352 + Math.cos(th) * hr, ctr.field_1351 + 15 - s * 2.4, ctr.field_1350 + Math.sin(th) * hr, 0, -0.02, 0);
            }
            for (int rr = 1; rr <= 3; rr++) {           // floor swirl
                double rad = R * rr / 3.0 * form;
                for (int s = 0; s < 28; s++) { double a = s * (Math.PI * 2 / 28) - spin; w.method_8406(class_2398.field_11202, ctr.field_1352 + Math.cos(a) * rad, ctr.field_1351 + 0.1, ctr.field_1350 + Math.sin(a) * rad, 0, 0, 0); }
            }
        }
        if ((t % 40) == 0) buffSeaCaster(c);
        class_238 box = new class_238(ctr.method_1023(R, R, R), ctr.method_1031(R, R, R));
        List<class_1308> mobs = w.method_8390(class_1308.class, box,
            e -> e.method_5805() && (e instanceof class_1588) && e.method_19538().method_1022(ctr) <= R + 1.0);
        for (class_1308 m : mobs) {
            class_243 mc2 = m.method_5829().method_1005();
            if ((t % 2) == 0) w.method_8406(class_2398.field_11247, mc2.field_1352, mc2.field_1351, mc2.field_1350, 0, 0, 0);
            if ((t % 4) == 0) seaHit(c, m, SEA_DMG);
        }
    }
    private void seaHit(class_310 c, class_1308 mob, float amt) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = mob.method_5667();
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983()); if (sw == null) return;
            class_1297 se = sw.method_14190(id);
            if (se instanceof class_1309 le) {
                le.method_64397(sw, sw.method_48963().method_48824(), amt);
                le.method_6092(new class_1293(class_1294.field_5909, 40, 2));
                le.method_6092(new class_1293(class_1294.field_5901, 40, 2));
            }
        });
    }

    // ---- 해일 (Tidal Wave) ----
    private void startWave(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687;
        waveTimer = WAVE_TICKS; wavePos = p.method_33571();
        class_243 look = p.method_5828(1.0f); class_243 flat = new class_243(look.field_1352, 0, look.field_1350);
        waveDir = flat.method_1027() < 1e-4 ? new class_243(0, 0, 1) : flat.method_1029();
        List<class_1308> mobs = w.method_8390(class_1308.class, p.method_5829().method_1014(10), e -> e.method_5805());
        for (class_1308 m : mobs) {
            class_243 to = m.method_5829().method_1005().method_1020(wavePos);
            if (to.method_1027() > 100) continue;
            class_243 fl = new class_243(to.field_1352, 0, to.field_1350);
            if (fl.method_1029().method_1026(waveDir) < 0.4) continue;
            damage(c, m, 18f); knockback(c, m, waveDir);
        }
    }
    private void tickWave(class_310 c) {
        if (wavePos == null || waveDir == null) return; class_638 w = c.field_1687;
        int el = WAVE_TICKS - waveTimer; double travel = el * 1.4;
        class_243 ctr = wavePos.method_1019(waveDir.method_1021(travel));
        class_243 right = waveDir.method_1036(new class_243(0, 1, 0)).method_1029();
        for (int i = -6; i <= 6; i++) {
            class_243 base = ctr.method_1019(right.method_1021(i * 0.9));
            for (int h = 0; h < 4; h++) {
                w.method_8406(class_2398.field_11202, base.field_1352, base.field_1351 + h * 0.7, base.field_1350, 0, 0.05, 0);
                if (h < 2) w.method_8406(class_2398.field_11247, base.field_1352, base.field_1351 + h * 0.7, base.field_1350, 0, 0, 0);
            }
        }
    }
    private void knockback(class_310 c, class_1308 mob, class_243 dir) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = mob.method_5667();
        final class_243 v = dir.method_1029().method_1021(1.7).method_1031(0, 0.5, 0);
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983()); if (sw == null) return;
            class_1297 se = sw.method_14190(id); if (se != null) se.method_18799(v);
        });
    }

    // ---- 소용돌이 (Maelstrom) ----
    private void startMaelstrom(class_310 c) {
        maelTimer = MAEL_TICKS;
        class_243 look = c.field_1724.method_5828(1.0f); class_243 flat = new class_243(look.field_1352, 0, look.field_1350);
        if (flat.method_1027() < 1e-4) flat = new class_243(0, 0, 1);
        maelPos = c.field_1724.method_19538().method_1019(flat.method_1029().method_1021(6)).method_1031(0, 0.1, 0);
    }
    private void tickMaelstrom(class_310 c) {
        if (maelPos == null) return; class_638 w = c.field_1687; long t = c.field_1724.field_6012; class_243 s = maelPos; double sp = t * 0.35;
        for (int rr = 1; rr <= 4; rr++) {
            double rad = rr * 1.4; int seg = 20;
            for (int i = 0; i < seg; i++) {
                double a = i * (Math.PI * 2 / seg) + sp - rr * 0.5;
                w.method_8406(class_2398.field_11247, s.field_1352 + Math.cos(a) * rad, s.field_1351 + (4 - rr) * 0.6, s.field_1350 + Math.sin(a) * rad, 0, 0, 0);
                if (rr == 1) w.method_8406(class_2398.field_11243, s.field_1352 + Math.cos(a) * rad, s.field_1351 + 3, s.field_1350 + Math.sin(a) * rad, 0, 0, 0);
            }
        }
        class_238 b = new class_238(s.method_1023(7, 4, 7), s.method_1031(7, 4, 7));
        List<class_1308> mobs = w.method_8390(class_1308.class, b,
            e -> e.method_5805() && (e instanceof class_1588) && e.method_19538().method_1022(s) <= 7.0);
        for (class_1308 m : mobs) { pullTo(c, m, s); if ((t % 4) == 0) seaHit(c, m, 6f); }
    }
    private void pullTo(class_310 c, class_1308 mob, class_243 center) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576(); if (server == null) return; UUID id = mob.method_5667();
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983()); if (sw == null) return;
            class_1297 se = sw.method_14190(id);
            if (se != null) { class_243 d = center.method_1020(se.method_19538()); if (d.method_1027() > 0.5) se.method_18799(d.method_1029().method_1021(0.5).method_1031(0, -0.1, 0)); }
        });
    }

    // ---- 상어 떼 (Shark Swarm) ----
    private void summonSharks(class_310 c) {
        sharks.clear(); class_243 base = c.field_1724.method_33571();
        for (int i = 0; i < MAX_SHARKS; i++) { double a = i * (Math.PI * 2 / MAX_SHARKS); sharks.add(new Crow(base.method_1031(Math.cos(a) * 3, 0.5, Math.sin(a) * 3), i)); }
    }
    private void tickSharks(class_310 c) {
        class_746 p = c.field_1724; class_638 w = c.field_1687; long t = p.field_6012;
        double step = Math.PI * 2 / Math.max(1, sharks.size());
        List<class_1308> host = w.method_8390(class_1308.class, p.method_5829().method_1014(18),
            e -> e.method_5805() && (e instanceof class_1588));
        for (Crow sk : sharks) {
            class_1308 tgt = host.stream().min(Comparator.comparingDouble(e -> e.method_5649(sk.pos.field_1352, sk.pos.field_1351, sk.pos.field_1350))).orElse(null);
            class_243 goal;
            if (tgt != null) goal = tgt.method_5829().method_1005();
            else { double a = sk.idx * step + t * 0.05; goal = p.method_33571().method_1031(Math.cos(a) * 3.5, 0.4 + Math.sin(t * 0.05 + sk.idx) * 0.3, Math.sin(a) * 3.5); }
            class_243 prev = sk.pos;
            sk.pos = sk.pos.method_1019(goal.method_1020(sk.pos).method_1021(0.18));
            double mvx = sk.pos.field_1352 - prev.field_1352, mvz = sk.pos.field_1350 - prev.field_1350;
            if (mvx * mvx + mvz * mvz > 1e-4) sk.face = Math.toDegrees(Math.atan2(-mvx, mvz));
            if ((t % 3) == 0) w.method_8406(class_2398.field_11247, sk.pos.field_1352, sk.pos.field_1351, sk.pos.field_1350, 0, 0, 0);
            if (sk.cd > 0) sk.cd--;
            if (tgt != null && sk.pos.method_1022(tgt.method_5829().method_1005()) < 2.6 && sk.cd <= 0) {
                damage(c, tgt, 10f); sk.cd = 12;
                class_243 tc = tgt.method_5829().method_1005();
                for (int k = 0; k < 4; k++) w.method_8406(class_2398.field_11202, tc.field_1352, tc.field_1351, tc.field_1350, 0, 0, 0);
            }
        }
    }

    private void renderSeaWorld(class_4587 ms, class_4597 vcp, class_310 mc, class_243 camPos, int light) {
        class_243 ctr = seaCenter; float age = mc.field_1724.field_6012;
        int elapsed = SEA_TICKS - seaTimer; float rise = Math.min(1f, elapsed / 18f);
        float ts = 3.0f * (0.25f + 0.75f * rise);
        double tLift = (22.5 * 0.991 / 16.0) * ts;
        renderModel(TEMPLE_STACK, ms, vcp, mc, camPos, light, ctr.field_1352, ctr.field_1351 + tLift, ctr.field_1350, ts, age * 0.3f, 0f, false);
        int PN = 8;
        for (int i = 0; i < PN; i++) {
            double a = i * (Math.PI * 2 / PN) + 0.2; float sc = 2.2f * (0.3f + 0.7f * rise); double lift = (18.5 / 16.0) * sc;
            double px = ctr.field_1352 + Math.cos(a) * SEA_RADIUS * 0.85, pz = ctr.field_1350 + Math.sin(a) * SEA_RADIUS * 0.85;
            renderModel(CORAL_STACK, ms, vcp, mc, camPos, light, px, ctr.field_1351 + lift, pz, sc, (float) (i * 47 % 360), 0f, false);
        }
        int SC = 4;
        for (int i = 0; i < SC; i++) {
            double a = i * (Math.PI * 2 / SC) + age * 0.02; double rad = SEA_RADIUS * 0.5;
            double cx = ctr.field_1352 + Math.cos(a) * rad, cz = ctr.field_1350 + Math.sin(a) * rad, cy = ctr.field_1351 + 8 + (i % 2) * 3 + Math.sin(age * 0.03 + i) * 1.2;
            renderModel(SHARK_STACK, ms, vcp, mc, camPos, light, cx, cy, cz, 1.2f, (float) Math.toDegrees(a) + 90, 0f, false);
        }
    }

    private void drawSeaOverlay(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int W = ctx.method_51421(), H = ctx.method_51443();
        int elapsed = SEA_TICKS - seaTimer; long t = c.field_1724.field_6012;
        float dk = Math.min(1f, elapsed / 16f); if (seaTimer < 20) dk *= seaTimer / 20f;
        ctx.method_25294(0, 0, W, H, ((int) (80 * dk) << 24) | 0x083048);   // deep-water blue tint
        int N = 60, maxIn = Math.min(W, H) * 3 / 5, band = Math.max(1, maxIn / N) + 1;
        for (int i = 0; i < N; i++) {
            int inset = i * maxIn / N;
            int a = (int) (200 * dk * Math.pow(1 - (double) i / N, 2.2));
            if (a <= 2) continue;
            int col = (a << 24) | 0x04202E;
            ctx.method_25294(inset, inset, W - inset, inset + band, col);
            ctx.method_25294(inset, H - inset - band, W - inset, H - inset, col);
            ctx.method_25294(inset, inset, inset + band, H - inset, col);
            ctx.method_25294(W - inset - band, inset, W - inset, H - inset, col);
        }
        ctx.method_25294(0, 0, W, 22, 0xAA000000);
        ctx.method_25294(0, H - 22, W, H, 0xAA000000);
        if (elapsed < 50) {
            String jp = "海の世界";
            boolean blink = (elapsed < 26) && ((t / 3) % 2 == 0);
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 48f, 0f);
            ctx.method_51448().method_22905(3.1f, 3.1f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(jp), -tr.method_1727(jp) / 2, 0, blink ? 0xFFFFFFFF : AQUA, true);
            ctx.method_51448().method_22909();
            String kr = "바다의 세계";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 16f, 0f);
            ctx.method_51448().method_22905(1.9f, 1.9f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(kr), -tr.method_1727(kr) / 2, 0, SEAB, true);
            ctx.method_51448().method_22909();
            String en = "O C E A N   W O R L D   ·   DROWN";
            ctx.method_51439(tr, class_2561.method_43470(en), W / 2 - tr.method_1727(en) / 2, H / 2 + 16, BON, true);
        } else {
            String b = "海 · 바다의 세계";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, 4f, 0f);
            ctx.method_51448().method_22905(1.3f, 1.3f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(b), -tr.method_1727(b) / 2, 0, AQUA, true);
            ctx.method_51448().method_22909();
        }
        int barW = 180, bx = W / 2 - barW / 2, by = H - 30;
        ctx.method_25294(bx - 1, by - 1, bx + barW + 1, by + 4, 0xFF08222E);
        int fillW = (int) (barW * seaTimer / (double) SEA_TICKS);
        ctx.method_25294(bx, by, bx + fillW, by + 3, AQUA);
        String sec = (seaTimer / 20 + 1) + "s";
        ctx.method_51439(tr, class_2561.method_43470(sec), bx + barW + 6, by - 3, AQUA, true);
    }
    private void drawTridentPanel(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int H = ctx.method_51443();
        int y0 = H - 120;
        ctx.method_51439(tr, class_2561.method_43470("SEA TRIDENT · 바다의 삼지창"), 8, y0, AQUA, true);
        ctx.method_51439(tr, class_2561.method_43470(seaTimer > 0 ? ">> 바다의 세계 " + (seaTimer / 20 + 1) + "s" : "= 바다의 세계 (J)"), 8, y0 + 12, seaTimer > 0 ? SEAB : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470(waveTimer > 0 ? ">> 해일" : "= 해일 (U)"), 8, y0 + 22, waveTimer > 0 ? AQUA : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470(maelTimer > 0 ? ">> 소용돌이 " + (maelTimer / 20 + 1) + "s" : "= 소용돌이 (Y)"), 8, y0 + 32, maelTimer > 0 ? AQUA : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470("상어 떼 소환 (M)  x" + sharks.size()), 8, y0 + 42, sharks.isEmpty() ? DIM : SEAB, true);
    }

    private void fireLaser(class_638 w, class_243 from, class_243 to) {
        int steps = (int) (from.method_1022(to) * 3) + 4;
        for (int i = 0; i <= steps; i++) {
            double f = i / (double) steps;
            w.method_8406(class_2398.field_11207,
                from.field_1352 + (to.field_1352 - from.field_1352) * f,
                from.field_1351 + (to.field_1351 - from.field_1351) * f,
                from.field_1350 + (to.field_1350 - from.field_1350) * f, 0, 0, 0);
        }
    }

    // Deal real damage in singleplayer (integrated server). Multiplayer = visual only.
    private void damage(class_310 c, class_1308 mob, float amt) {
        if (renderingRemote) return;
        MinecraftServer server = c.method_1576();
        if (server == null) return;
        UUID id = mob.method_5667();
        server.execute(() -> {
            class_3218 sw = server.method_3847(c.field_1687.method_27983());
            if (sw == null) return;
            class_1297 se = sw.method_14190(id);
            if (se instanceof class_1309 le) {
                le.method_64397(sw, sw.method_48963().method_48831(), amt);
            }
        });
    }

    private void aimAt(class_746 p, class_1297 t) {
        class_243 eye = p.method_33571();
        double dx = t.method_23317() - eye.field_1352;
        double dy = (t.method_23318() + t.method_17682() * 0.5) - eye.field_1351;
        double dz = t.method_23321() - eye.field_1350;
        double distXZ = Math.sqrt(dx * dx + dz * dz);
        float wantYaw   = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantPitch = (float) (-Math.toDegrees(Math.atan2(dy, distXZ)));
        p.method_36456(p.method_36454() + class_3532.method_15393(wantYaw - p.method_36454()) * AIM);
        p.method_36457(p.method_36455() + (wantPitch - p.method_36455()) * AIM);
    }

    // ---- tiny draw helpers (DrawContext only has fill/drawText) ----
    private static void dot(class_332 g,int x,int y,int col){ g.method_25294(x,y,x+1,y+1,col); }
    private static void hLine(class_332 g,int x1,int x2,int y,int col){ g.method_25294(Math.min(x1,x2),y,Math.max(x1,x2)+1,y+1,col); }
    private static void vLine(class_332 g,int x,int y1,int y2,int col){ g.method_25294(x,Math.min(y1,y2),x+1,Math.max(y1,y2)+1,col); }
    private static void line(class_332 g,int x0,int y0,int x1,int y1,int col){
        int dx=Math.abs(x1-x0), dy=Math.abs(y1-y0), sx=x0<x1?1:-1, sy=y0<y1?1:-1, err=dx-dy;
        for(int n=0;n<400;n++){ dot(g,x0,y0,col); if(x0==x1&&y0==y1)break; int e2=2*err; if(e2>-dy){err-=dy;x0+=sx;} if(e2<dx){err+=dx;y0+=sy;} }
    }
    private static void ring(class_332 g,int cx,int cy,int r,int col){
        int seg=Math.max(28,r*3); for(int i=0;i<seg;i++){ double a=i*2*Math.PI/seg; dot(g,cx+(int)Math.round(Math.cos(a)*r),cy+(int)Math.round(Math.sin(a)*r),col); }
    }

    // ---- DOMAIN EXPANSION full-screen overlay (領域展開 · 기계의 세계) ----
    private void drawDomainOverlay(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int W = ctx.method_51421();
        int H = ctx.method_51443();
        int elapsed = DOMAIN_TICKS - domainTimer;
        long t = c.field_1724.field_6012;

        // ===== VOID DARKNESS: everything outside the domain sinks into black =====
        float dk = Math.min(1f, elapsed / 16f);              // darkness forms with the domain
        if (domainTimer < 20) dk *= domainTimer / 20f;       // eases out as it ends
        // faint deep-navy void tint over the whole view
        ctx.method_25294(0, 0, W, H, ((int) (70 * dk) << 24) | 0x0A0E1E);
        // radial vignette: nested dark frames, strong at the edges, clear in the center
        int N = 64;
        int maxIn = Math.min(W, H) * 3 / 5;
        int band = Math.max(1, maxIn / N) + 1;
        for (int i = 0; i < N; i++) {
            int inset = i * maxIn / N;
            int a = (int) (225 * dk * Math.pow(1 - (double) i / N, 2.3));
            if (a <= 2) continue;
            int col = (a << 24) | 0x02040A;                  // near-black, faint blue
            ctx.method_25294(inset, inset, W - inset, inset + band, col);            // top
            ctx.method_25294(inset, H - inset - band, W - inset, H - inset, col);    // bottom
            ctx.method_25294(inset, inset, inset + band, H - inset, col);            // left
            ctx.method_25294(W - inset - band, inset, W - inset, H - inset, col);    // right
        }

        // activation flash (cyan-white burst), first 10 ticks
        if (elapsed < 10) {
            int a = (int) (210 * (1 - elapsed / 10.0));
            ctx.method_25294(0, 0, W, H, (a << 24) | 0x8FF6FF);
        }
        // cinematic letterbox + moving scanline
        ctx.method_25294(0, 0, W, 22, 0x99000000);
        ctx.method_25294(0, H - 22, W, H, 0x99000000);
        int sy = (int) ((t * 5) % H);
        hLine(ctx, 0, W, sy, 0x2241E9FF);

        if (elapsed < 48) {
            // ---- dramatic reveal: 領域展開 / 기계의 세계 ----
            String jp = "領域展開";
            boolean blink = (elapsed < 26) && ((t / 3) % 2 == 0);
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 48f, 0f);
            ctx.method_51448().method_22905(3.0f, 3.0f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(jp), -tr.method_1727(jp) / 2, 0, blink ? 0xFFFFFFFF : CY, true);
            ctx.method_51448().method_22909();

            String kr = "기 계 의  세 계";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 18f, 0f);
            ctx.method_51448().method_22905(1.7f, 1.7f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(kr), -tr.method_1727(kr) / 2, 0, VIO, true);
            ctx.method_51448().method_22909();

            String en = "M A C H I N E   W O R L D   ·   SURE-HIT";
            ctx.method_51439(tr, class_2561.method_43470(en), W / 2 - tr.method_1727(en) / 2, H / 2 + 14, DIM, true);
        } else {
            // ---- compact banner once the name has faded ----
            String b = "領域 · 기계의 세계";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, 4f, 0f);
            ctx.method_51448().method_22905(1.3f, 1.3f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(b), -tr.method_1727(b) / 2, 0, CY, true);
            ctx.method_51448().method_22909();
        }

        // remaining-time bar
        int barW = 170, bx = W / 2 - barW / 2, by = H - 30;
        ctx.method_25294(bx - 1, by - 1, bx + barW + 1, by + 4, 0xFF10202A);
        int fillW = (int) (barW * domainTimer / (double) DOMAIN_TICKS);
        ctx.method_25294(bx, by, bx + fillW, by + 3, CY);
        String sec = (domainTimer / 20 + 1) + "s";
        ctx.method_51439(tr, class_2561.method_43470(sec), bx + barW + 6, by - 3, CY, true);
    }

    // ---- CROW GRAVE overlay (領域展開 · 까마귀들의 무덤) — darker & fouler ----
    private void drawCrowOverlay(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int W = ctx.method_51421();
        int H = ctx.method_51443();
        int elapsed = CROW_DOMAIN_TICKS - crowDomainTimer;
        long t = c.field_1724.field_6012;

        // void darkness swallowing the world (heavier than the machine domain)
        float dk = Math.min(1f, elapsed / 16f);
        if (crowDomainTimer < 20) dk *= crowDomainTimer / 20f;
        ctx.method_25294(0, 0, W, H, ((int) (95 * dk) << 24) | 0x060A06);   // sickly dark tint
        int N = 64, maxIn = Math.min(W, H) * 3 / 5, band = Math.max(1, maxIn / N) + 1;
        for (int i = 0; i < N; i++) {
            int inset = i * maxIn / N;
            int a = (int) (235 * dk * Math.pow(1 - (double) i / N, 2.2));
            if (a <= 2) continue;
            int col = (a << 24) | 0x030603;
            ctx.method_25294(inset, inset, W - inset, inset + band, col);
            ctx.method_25294(inset, H - inset - band, W - inset, H - inset, col);
            ctx.method_25294(inset, inset, inset + band, H - inset, col);
            ctx.method_25294(W - inset - band, inset, W - inset, H - inset, col);
        }
        // faint green poison haze at the very bottom
        ctx.method_25294(0, H - 40, W, H, (((int) (40 * dk)) << 24) | 0x2E5A18);

        // HEARTBEAT blood pulse — the edges throb red like a dying heart
        double beat = Math.max(0, Math.sin(t * 0.18)) * Math.max(0, Math.sin(t * 0.18));
        int pulse = (int) (150 * dk * beat);
        if (pulse > 3) {
            int bandp = Math.max(1, maxIn / N) + 1;
            for (int i = 0; i < N; i++) {
                int inset = i * maxIn / N;
                int a = (int) (pulse * Math.pow(1 - (double) i / N, 2.6));
                if (a <= 2) continue;
                int col = (a << 24) | 0x6A0202;
                ctx.method_25294(inset, inset, W - inset, inset + bandp, col);
                ctx.method_25294(inset, H - inset - bandp, W - inset, H - inset, col);
                ctx.method_25294(inset, inset, inset + bandp, H - inset, col);
                ctx.method_25294(W - inset - bandp, inset, W - inset, H - inset, col);
            }
        }
        // blood dripping down from the top edge
        for (int i = 0; i < 26; i++) {
            int dx2 = (i * 61 + 13) % W;
            int len = (int) (6 + 10 * (0.5 + 0.5 * Math.sin(i * 1.7 + t * 0.05)));
            ctx.method_25294(dx2, 22, dx2 + 2, 22 + len, (((int) (170 * dk)) << 24) | 0x6A0202);
        }

        ctx.method_25294(0, 0, W, 22, 0xB0000000);
        ctx.method_25294(0, H - 22, W, H, 0xB0000000);

        if (elapsed < 50) {
            String jp = "領域展開";
            boolean blink = (elapsed < 28) && ((t / 3) % 2 == 0);
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 48f, 0f);
            ctx.method_51448().method_22905(3.0f, 3.0f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(jp), -tr.method_1727(jp) / 2, 0, blink ? 0xFFFFFFFF : BON, true);
            ctx.method_51448().method_22909();
            String kr = "까마귀들의 무덤";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 16f, 0f);
            ctx.method_51448().method_22905(1.9f, 1.9f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(kr), -tr.method_1727(kr) / 2, 0, RED, true);
            ctx.method_51448().method_22909();
            String en = "G R A V E   O F   C R O W S   ·   POISON";
            ctx.method_51439(tr, class_2561.method_43470(en), W / 2 - tr.method_1727(en) / 2, H / 2 + 16, GRN, true);
        } else {
            String b = "領域 · 까마귀들의 무덤";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, 4f, 0f);
            ctx.method_51448().method_22905(1.3f, 1.3f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(b), -tr.method_1727(b) / 2, 0, BON, true);
            ctx.method_51448().method_22909();
        }
        int barW = 170, bx = W / 2 - barW / 2, by = H - 30;
        ctx.method_25294(bx - 1, by - 1, bx + barW + 1, by + 4, 0xFF201810);
        int fillW = (int) (barW * crowDomainTimer / (double) CROW_DOMAIN_TICKS);
        ctx.method_25294(bx, by, bx + fillW, by + 3, GRN);
        String sec = (crowDomainTimer / 20 + 1) + "s";
        ctx.method_51439(tr, class_2561.method_43470(sec), bx + barW + 6, by - 3, GRN, true);
    }

    // ---- small skill panel while the Crow Fan is held ----
    private void drawFanPanel(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int y0 = shadesOn(c) ? 96 : 8;
        ctx.method_51439(tr, class_2561.method_43470("CROW FAN · 까마귀의 부채"), 8, y0, BON, true);
        ctx.method_51439(tr, class_2561.method_43470((crowDomainTimer > 0 ? ">> 세계 ACTIVE " + (crowDomainTimer / 20 + 1) + "s" : "= 세계 (R)")), 8, y0 + 12, crowDomainTimer > 0 ? RED : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470("까마귀 소환 (C)  x" + crows.size()), 8, y0 + 22, crows.isEmpty() ? DIM : PUR, true);
        ctx.method_51439(tr, class_2561.method_43470((wingsTimer > 0 ? ">> 날개 " + (wingsTimer / 20 + 1) + "s" : "= 까마귀의 날개 (V)")), 8, y0 + 32, wingsTimer > 0 ? GRN : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470((sealTimer > 0 ? ">> 봉인 " + (sealTimer / 20 + 1) + "s" : "= 망자 봉인 (X)")), 8, y0 + 42, sealTimer > 0 ? PUR : DIM, true);
    }

    // ---- DUEL ARENA overlay (決闘場 · 전사들의 결투장) — golden & grand ----
    private void drawArenaOverlay(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int W = ctx.method_51421();
        int H = ctx.method_51443();
        int elapsed = ARENA_TICKS - arenaTimer;
        long t = c.field_1724.field_6012;

        float dk = Math.min(1f, elapsed / 16f);
        if (arenaTimer < 20) dk *= arenaTimer / 20f;
        ctx.method_25294(0, 0, W, H, ((int) (55 * dk) << 24) | 0x140C04);   // warm dusk tint
        int N = 60, maxIn = Math.min(W, H) * 3 / 5, band = Math.max(1, maxIn / N) + 1;
        for (int i = 0; i < N; i++) {
            int inset = i * maxIn / N;
            int a = (int) (200 * dk * Math.pow(1 - (double) i / N, 2.2));
            if (a <= 2) continue;
            int col = (a << 24) | 0x1A1206;
            ctx.method_25294(inset, inset, W - inset, inset + band, col);
            ctx.method_25294(inset, H - inset - band, W - inset, H - inset, col);
            ctx.method_25294(inset, inset, inset + band, H - inset, col);
            ctx.method_25294(W - inset - band, inset, W - inset, H - inset, col);
        }
        ctx.method_25294(0, 0, W, 22, 0xAA000000);
        ctx.method_25294(0, H - 22, W, H, 0xAA000000);

        if (elapsed < 52) {
            String jp = "決闘場";
            boolean blink = (elapsed < 26) && ((t / 3) % 2 == 0);
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 50f, 0f);
            ctx.method_51448().method_22905(3.2f, 3.2f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(jp), -tr.method_1727(jp) / 2, 0, blink ? 0xFFFFFFFF : GLD, true);
            ctx.method_51448().method_22909();
            String kr = "전사들의 결투장";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 16f, 0f);
            ctx.method_51448().method_22905(1.9f, 1.9f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(kr), -tr.method_1727(kr) / 2, 0, CRM, true);
            ctx.method_51448().method_22909();
            String en = "D U E L   A R E N A   ·   1  vs  1";
            ctx.method_51439(tr, class_2561.method_43470(en), W / 2 - tr.method_1727(en) / 2, H / 2 + 16, BON, true);
        } else {
            String b = "決闘場 · 전사들의 결투장";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, 4f, 0f);
            ctx.method_51448().method_22905(1.3f, 1.3f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(b), -tr.method_1727(b) / 2, 0, GLD, true);
            ctx.method_51448().method_22909();
        }
        // versus line + buff/debuff readout
        String vs = "VS  " + opponentName;
        ctx.method_51439(tr, class_2561.method_43470(vs), W / 2 - tr.method_1727(vs) / 2, H / 2 + 30, 0xFFFFFFFF, true);
        String me = "나 : 힘+ 속도+ 채굴+ 방어+";
        String foe = "상대 : 나약함- 둔화-";
        ctx.method_51439(tr, class_2561.method_43470(me), 10, H - 44, GLD, true);
        ctx.method_51439(tr, class_2561.method_43470(foe), W - 10 - tr.method_1727(foe), H - 44, CRM, true);

        int barW = 180, bx = W / 2 - barW / 2, by = H - 30;
        ctx.method_25294(bx - 1, by - 1, bx + barW + 1, by + 4, 0xFF241A08);
        int fillW = (int) (barW * arenaTimer / (double) ARENA_TICKS);
        ctx.method_25294(bx, by, bx + fillW, by + 3, GLD);
        String sec = (arenaTimer / 20 + 1) + "s";
        ctx.method_51439(tr, class_2561.method_43470(sec), bx + barW + 6, by - 3, GLD, true);
    }

    private void drawSwordPanel(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int H = ctx.method_51443();
        int y0 = H - 120;
        ctx.method_51439(tr, class_2561.method_43470("DUEL BLADE · 결투장의 대검"), 8, y0, GLD, true);
        ctx.method_51439(tr, class_2561.method_43470(arenaTimer > 0 ? ">> 결투장 " + (arenaTimer / 20 + 1) + "s  VS " + opponentName : "= 전사들의 결투장 (B)"),
            8, y0 + 12, arenaTimer > 0 ? CRM : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470(berserkTimer > 0 ? ">> 광폭화 " + (berserkTimer / 20 + 1) + "s" : "= 광폭화 (Z)"),
            8, y0 + 22, berserkTimer > 0 ? CRM : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470("혈검술 (N)  — 피를 깎아 참격"), 8, y0 + 32, slashTimer > 0 ? CRM : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470("전사의 심판 — 원거리 상대 즉사"), 8, y0 + 42, judgmentTimer > 0 ? CRM : DIM, true);
    }

    // full-screen effects for the sword skills (berserk aura, judgment banner)
    private void drawSwordFx(class_332 ctx, class_310 c) {
        class_327 tr = c.field_1772;
        int W = ctx.method_51421(), H = ctx.method_51443();
        long t = c.field_1724.field_6012;
        if (berserkTimer > 0) {
            double beat = 0.55 + 0.45 * Math.sin(t * 0.3);
            double fade = Math.min(1.0, berserkTimer / 20.0);
            int N = 42, maxIn = Math.min(W, H) / 2, band = Math.max(1, maxIn / N) + 1;
            for (int i = 0; i < N; i++) {
                int inset = i * maxIn / N;
                int a = (int) (95 * fade * beat * Math.pow(1 - (double) i / N, 2.4));
                if (a <= 2) continue;
                int col = (a << 24) | 0x8A0410;
                ctx.method_25294(inset, inset, W - inset, inset + band, col);
                ctx.method_25294(inset, H - inset - band, W - inset, H - inset, col);
                ctx.method_25294(inset, inset, inset + band, H - inset, col);
                ctx.method_25294(W - inset - band, inset, W - inset, H - inset, col);
            }
            String bz = "光 · 광폭화 BERSERK";
            ctx.method_51439(tr, class_2561.method_43470(bz), W / 2 - tr.method_1727(bz) / 2, 30, CRM, true);
        }
        if (judgmentTimer > 0) {
            int a = (int) (140 * Math.min(1.0, judgmentTimer / 12.0));
            ctx.method_25294(0, 0, W, H, (a << 24) | 0x2A0006);
            String jp = "戦士の審判";
            boolean blink = ((t / 2) % 2 == 0);
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 46f, 0f);
            ctx.method_51448().method_22905(3.4f, 3.4f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(jp), -tr.method_1727(jp) / 2, 0, blink ? 0xFFFFFFFF : CRM, true);
            ctx.method_51448().method_22909();
            String kr = "전사의 심판";
            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(W / 2f, H / 2f - 12f, 0f);
            ctx.method_51448().method_22905(2.0f, 2.0f, 1f);
            ctx.method_51439(tr, class_2561.method_43470(kr), -tr.method_1727(kr) / 2, 0, GLD, true);
            ctx.method_51448().method_22909();
            String en = "W A R R I O R ' S   J U D G M E N T   ·   즉사";
            ctx.method_51439(tr, class_2561.method_43470(en), W / 2 - tr.method_1727(en) / 2, H / 2 + 18, BON, true);
        }
    }

    private void onHud(class_332 ctx, class_9779 counter) {
        class_310 c = class_310.method_1551();
        if (c.field_1724 == null || c.field_1687 == null) return;
        // Domain overlay renders whenever the domain is up + shades on (even in standby).
        if (domainTimer > 0 && shadesOn(c)) drawDomainOverlay(ctx, c);
        // Crow-grave overlay + fan HUD render whenever the fan is held.
        if (crowDomainTimer > 0 && heldFan(c)) drawCrowOverlay(ctx, c);
        if (heldFan(c)) drawFanPanel(ctx, c);
        // Duel arena overlay + sword HUD render whenever the greatsword is held.
        if (arenaTimer > 0 && heldSword(c)) drawArenaOverlay(ctx, c);
        if (heldSword(c)) { drawSwordPanel(ctx, c); drawSwordFx(ctx, c); }
        // Ocean world overlay + trident HUD whenever the trident is held.
        if (seaTimer > 0 && heldTrident(c)) drawSeaOverlay(ctx, c);
        if (heldTrident(c)) drawTridentPanel(ctx, c);
        if (!active(c)) return;
        class_746 p = c.field_1724;
        class_327 tr = c.field_1772;
        int W = ctx.method_51421();
        int Hh = ctx.method_51443();
        long t = p.field_6012;

        List<class_1309> hostiles = c.field_1687.method_8390(class_1309.class,
            p.method_5829().method_1014(RANGE),
            e -> e.method_5805() && e != p && ((e instanceof class_1588) || (e instanceof class_1657)));

        // ---------- top-left system panel ----------
        ctx.method_51439(tr, class_2561.method_43470("J.A.R.V.I.S"), 8, 8, CY, true);
        ctx.method_51439(tr, class_2561.method_43470("VOID HUNT PROTOCOL"), 8, 18, DIM, true);
        String clock = String.format("%02d:%02d", java.time.LocalTime.now().getHour(), java.time.LocalTime.now().getMinute());
        ctx.method_51439(tr, class_2561.method_43470((huntMode ? "> HUNTING" : "= STANDBY") + "   " + clock), 8, 30, huntMode ? AMB : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470("TARGETS " + hostiles.size() + "   RANGE " + (int) RANGE + "m"), 8, 42, CY, true);
        ctx.method_51439(tr, class_2561.method_43470(target != null ? "LOCK  >> LOCKED" : "LOCK  -- SEARCHING"), 8, 54, target != null ? AMB : DIM, true);
        ctx.method_51439(tr, class_2561.method_43470("DRONES " + drones.size() + "/" + MAX_DRONES + "  (K)   ULT (O)"), 8, 66, drones.isEmpty() ? DIM : VIO, true);
        ctx.method_51439(tr, class_2561.method_43470(domainTimer > 0 ? "DOMAIN >> ACTIVE (G)" : "DOMAIN -- READY (G)"), 8, 78, domainTimer > 0 ? RED : DIM, true);

        // ---------- ULTIMATE banner ----------
        if (ultTimer > 0) {
            String u = ">> ORBITAL STRIKE <<   " + (ultTimer / 20 + 1) + "s";
            int uw = tr.method_1727(u);
            ctx.method_25294(W / 2 - uw / 2 - 12, 82, W / 2 + uw / 2 + 12, 100, 0xAA000000);
            hLine(ctx, W / 2 - uw / 2 - 12, W / 2 + uw / 2 + 12, 82, 0xFFFF3050);
            hLine(ctx, W / 2 - uw / 2 - 12, W / 2 + uw / 2 + 12, 100, 0xFFFF3050);
            ctx.method_51439(tr, class_2561.method_43470(u), W / 2 - uw / 2, 87, 0xFFFF5070, true);
        }

        // ---------- top-right radar ----------
        int rcx = W - 58, rcy = 60, R = 44;
        ctx.method_25294(rcx - R - 6, rcy - R - 6, rcx + R + 6, rcy + R + 6, 0x66000000);
        ring(ctx, rcx, rcy, R, 0x8841E9FF);
        ring(ctx, rcx, rcy, R * 2 / 3, 0x5541E9FF);
        ring(ctx, rcx, rcy, R / 3, 0x5541E9FF);
        hLine(ctx, rcx - R, rcx + R, rcy, 0x4441E9FF);
        vLine(ctx, rcx, rcy - R, rcy + R, 0x4441E9FF);
        double sweep = (t * 0.06) % (2 * Math.PI);
        line(ctx, rcx, rcy, rcx + (int) (Math.cos(sweep) * R), rcy + (int) (Math.sin(sweep) * R), 0xAA41E9FF);
        float yawR = (float) Math.toRadians(p.method_36454());
        double fwx = -Math.sin(yawR), fwz = Math.cos(yawR);   // forward
        double rgx = Math.cos(yawR),  rgz = Math.sin(yawR);   // right
        for (class_1309 m : hostiles) {
            double relX = m.method_23317() - p.method_23317(), relZ = m.method_23321() - p.method_23321();
            double forward = relX * fwx + relZ * fwz;
            double rightd  = relX * rgx + relZ * rgz;
            int bx = rcx + (int) (rightd / RANGE * R);
            int by = rcy - (int) (forward / RANGE * R);
            int col = (target != null && m == target) ? AMB : ((m instanceof class_1657) ? PUR : (m.method_6063() >= 40 ? RED : CY));
            ctx.method_25294(bx - 1, by - 1, bx + 2, by + 2, col);
        }
        ctx.method_25294(rcx - 1, rcy - 1, rcx + 2, rcy + 2, 0xFF8FF6FF);

        // ---------- center lock reticle ----------
        int mx = W / 2, my = Hh / 2;
        if (target != null) {
            int L = 11, T = 2, col = AMB;
            ctx.method_25294(mx - L, my - L, mx - T, my - L + 1, col); ctx.method_25294(mx - L, my - L, mx - L + 1, my - T, col);
            ctx.method_25294(mx + T, my - L, mx + L, my - L + 1, col); ctx.method_25294(mx + L - 1, my - L, mx + L, my - T, col);
            ctx.method_25294(mx - L, my + L - 1, mx - T, my + L, col); ctx.method_25294(mx - L, my + T, mx - L + 1, my + L, col);
            ctx.method_25294(mx + T, my + L - 1, mx + L, my + L, col); ctx.method_25294(mx + L - 1, my + T, mx + L, my + L, col);
        }

        // ---------- bottom-center target card ----------
        if (target != null) {
            String nm = target.method_5477().getString();
            float hp = target.method_6032(), mhp = Math.max(1f, target.method_6063());
            float dist = p.method_5739(target);
            String threat = mhp >= 40 ? "HIGH" : (mhp >= 20 ? "MED" : "LOW");
            boolean exec = hp / mhp <= 0.2f;
            String meta = "DIST " + String.format("%.1fm", dist) + "  |  THREAT " + threat;
            int tw = Math.max(96, Math.max(tr.method_1727(nm), tr.method_1727(meta)));
            int cx = W / 2, ty = Hh - 58;
            ctx.method_25294(cx - tw / 2 - 8, ty - 6, cx + tw / 2 + 8, ty + 30, 0xB0000000);
            hLine(ctx, cx - tw / 2 - 8, cx + tw / 2 + 8, ty - 6, 0x8841E9FF);
            ctx.method_51439(tr, class_2561.method_43470(nm), cx - tr.method_1727(nm) / 2, ty, 0xFFFFFFFF, true);
            ctx.method_51439(tr, class_2561.method_43470(meta), cx - tr.method_1727(meta) / 2, ty + 11, DIM, true);
            int bx = cx - tw / 2, by = ty + 23, bw = tw;
            ctx.method_25294(bx - 1, by - 1, bx + bw + 1, by + 4, 0xFF20323A);
            ctx.method_25294(bx, by, bx + (int) (bw * Math.max(0f, hp / mhp)), by + 3, exec ? 0xFFFF2040 : RED);
            String hptxt = (int) Math.ceil(hp) + "/" + (int) mhp;
            ctx.method_51439(tr, class_2561.method_43470(hptxt), cx + tw / 2 - tr.method_1727(hptxt), by - 9, 0xFFFFFFFF, true);
            if (exec) {
                String ex = "!! EXECUTE";
                ctx.method_51439(tr, class_2561.method_43470(ex), cx - tr.method_1727(ex) / 2, ty - 16, 0xFFFF3050, true);
            }
        }

        // ---------- bottom-right ELIMINATED counter ----------
        String kb = String.valueOf(kills);
        ctx.method_51439(tr, class_2561.method_43470(kb), W - 16 - tr.method_1727(kb), Hh - 40, 0xFFFFFFFF, true);
        ctx.method_51439(tr, class_2561.method_43470("ELIMINATED"), W - 16 - tr.method_1727("ELIMINATED"), Hh - 28, DIM, true);
        if (combo > 1) {
            String cb = "COMBO x" + combo;
            ctx.method_51439(tr, class_2561.method_43470(cb), W - 16 - tr.method_1727(cb), Hh - 52, AMB, true);
        }
    }
}
