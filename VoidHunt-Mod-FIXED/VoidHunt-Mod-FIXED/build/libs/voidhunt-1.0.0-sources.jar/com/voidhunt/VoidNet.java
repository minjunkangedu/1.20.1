package com.voidhunt;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Networking for sharing Void-Hunt visual effects with nearby players. */
public final class VoidNet {

    /** A snapshot of one caster's active visuals. */
    public static final class Fx {
        public class_243 mCtr, cCtr, aCtr, jPos, sCtr;  // domain / crow / arena / judgment / sea centers
        public int mT, cT, aT, uT, jT, bT, sT;      // timers (0 = off), uT=ult, bT=berserk, sT=sea
        public final List<class_243> drones = new ArrayList<>();
        public final List<class_243> crows  = new ArrayList<>();
        public final List<class_243> sharks = new ArrayList<>();
        public int age = 0;                        // client-side: ticks since last packet
        public boolean anyActive() {
            return mT > 0 || cT > 0 || aT > 0 || uT > 0 || jT > 0 || bT > 0 || sT > 0
                || !drones.isEmpty() || !crows.isEmpty() || !sharks.isEmpty();
        }
    }

    private static void wVec(class_9129 b, class_243 v) {
        boolean has = v != null; b.method_52964(has);
        if (has) { b.method_52940(v.field_1352); b.method_52940(v.field_1351); b.method_52940(v.field_1350); }
    }
    private static class_243 rVec(class_9129 b) {
        if (!b.readBoolean()) return null;
        return new class_243(b.readDouble(), b.readDouble(), b.readDouble());
    }
    private static void wBody(class_9129 b, Fx f) {
        wVec(b, f.mCtr); b.method_10804(f.mT);
        wVec(b, f.cCtr); b.method_10804(f.cT);
        wVec(b, f.aCtr); b.method_10804(f.aT);
        b.method_10804(f.uT);
        wVec(b, f.jPos); b.method_10804(f.jT);
        b.method_10804(f.bT);
        wVec(b, f.sCtr); b.method_10804(f.sT);
        b.method_10804(f.drones.size()); for (class_243 v : f.drones) { b.method_52940(v.field_1352); b.method_52940(v.field_1351); b.method_52940(v.field_1350); }
        b.method_10804(f.crows.size());  for (class_243 v : f.crows)  { b.method_52940(v.field_1352); b.method_52940(v.field_1351); b.method_52940(v.field_1350); }
        b.method_10804(f.sharks.size()); for (class_243 v : f.sharks) { b.method_52940(v.field_1352); b.method_52940(v.field_1351); b.method_52940(v.field_1350); }
    }
    private static Fx rBody(class_9129 b) {
        Fx f = new Fx();
        f.mCtr = rVec(b); f.mT = b.method_10816();
        f.cCtr = rVec(b); f.cT = b.method_10816();
        f.aCtr = rVec(b); f.aT = b.method_10816();
        f.uT = b.method_10816();
        f.jPos = rVec(b); f.jT = b.method_10816();
        f.bT = b.method_10816();
        f.sCtr = rVec(b); f.sT = b.method_10816();
        int n = b.method_10816(); for (int i = 0; i < n; i++) f.drones.add(new class_243(b.readDouble(), b.readDouble(), b.readDouble()));
        int m = b.method_10816(); for (int i = 0; i < m; i++) f.crows.add(new class_243(b.readDouble(), b.readDouble(), b.readDouble()));
        int k = b.method_10816(); for (int i = 0; i < k; i++) f.sharks.add(new class_243(b.readDouble(), b.readDouble(), b.readDouble()));
        return f;
    }

    /** Client -> server: my current effect snapshot. */
    public record PushC2S(Fx fx) implements class_8710 {
        public static final class_9154<PushC2S> ID = new class_9154<>(class_2960.method_60655(VoidHunt.MOD_ID, "fx_c2s"));
        public static final class_9139<class_9129, PushC2S> CODEC =
            class_9139.method_56438((v, b) -> wBody(b, v.fx), b -> new PushC2S(rBody(b)));
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    /** Server -> client: someone else's effect snapshot. */
    public record SyncS2C(UUID owner, Fx fx) implements class_8710 {
        public static final class_9154<SyncS2C> ID = new class_9154<>(class_2960.method_60655(VoidHunt.MOD_ID, "fx_s2c"));
        public static final class_9139<class_9129, SyncS2C> CODEC =
            class_9139.method_56438((v, b) -> { b.method_10797(v.owner); wBody(b, v.fx); },
                           b -> { UUID o = b.method_10790(); return new SyncS2C(o, rBody(b)); });
        public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public static void registerCommon() {
        PayloadTypeRegistry.playC2S().register(PushC2S.ID, PushC2S.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncS2C.ID, SyncS2C.CODEC);
    }

    /** Server relays each snapshot to nearby players in the same world. */
    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(PushC2S.ID, (payload, context) -> {
            class_3222 from = context.player();
            from.method_5682().execute(() -> {
                class_3218 w = (class_3218) from.method_5770();
                SyncS2C out = new SyncS2C(from.method_5667(), payload.fx());
                for (class_3222 pl : from.method_5682().method_3760().method_14571()) {
                    if (pl == from) continue;
                    if (pl.method_5770() != w) continue;
                    if (pl.method_5858(from) > 160 * 160) continue;
                    ServerPlayNetworking.send(pl, out);
                }
            });
        });
    }
}
