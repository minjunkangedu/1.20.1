package com.voidhunt;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9334;

public class VoidHunt implements ModInitializer {
    public static final String MOD_ID = "voidhunt";

    public static final class_5321<class_1792> SHADES_KEY =
        class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "void_shades"));

    // Wearable on the HEAD slot; renders its own 3D item model (no equipment asset set).
    public static final class_1792 VOID_SHADES = new class_1792(new class_1792.class_1793()
        .method_63686(SHADES_KEY)
        .method_7889(1)
        .method_7894(class_1814.field_8904)
        .method_57349(class_9334.field_54196,
            class_10192.method_64202(class_1304.field_6169).method_64203()));

    // Drone item — only used to render the 3D drone model in the world.
    public static final class_5321<class_1792> DRONE_KEY =
        class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "void_drone"));
    public static final class_1792 VOID_DRONE = new class_1792(new class_1792.class_1793()
        .method_63686(DRONE_KEY)
        .method_7889(1)
        .method_7894(class_1814.field_8904));

    // Satellite item — renders the 3D orbital-strike satellite during the ultimate.
    public static final class_5321<class_1792> SAT_KEY =
        class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "void_satellite"));
    public static final class_1792 VOID_SATELLITE = new class_1792(new class_1792.class_1793()
        .method_63686(SAT_KEY)
        .method_7889(1)
        .method_7894(class_1814.field_8904));

    // Domain structures — 3D props rendered inside the Domain Expansion.
    public static final class_5321<class_1792> GEAR_KEY =
        class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "void_gear"));
    public static final class_1792 VOID_GEAR = new class_1792(new class_1792.class_1793()
        .method_63686(GEAR_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> CORE_KEY =
        class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "void_core"));
    public static final class_1792 VOID_CORE = new class_1792(new class_1792.class_1793()
        .method_63686(CORE_KEY).method_7889(1).method_7894(class_1814.field_8904));

    // ===== CROW GRAVE set — the Crow Fan weapon + its summonable structures =====
    private static class_5321<class_1792> ck(String id) {
        return class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, id));
    }
    public static final class_5321<class_1792> FAN_KEY  = ck("crow_fan");
    public static final class_1792 CROW_FAN = new class_1792(new class_1792.class_1793()
        .method_63686(FAN_KEY).method_7889(1).method_7894(class_1814.field_8904));   // the held weapon
    public static final class_5321<class_1792> CROW_KEY = ck("crow");
    public static final class_1792 CROW = new class_1792(new class_1792.class_1793().method_63686(CROW_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> TOMB_KEY = ck("tombstone");
    public static final class_1792 TOMBSTONE = new class_1792(new class_1792.class_1793().method_63686(TOMB_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> TORII_KEY = ck("torii");
    public static final class_1792 TORII = new class_1792(new class_1792.class_1793().method_63686(TORII_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> TREE_KEY = ck("dead_tree");
    public static final class_1792 DEAD_TREE = new class_1792(new class_1792.class_1793().method_63686(TREE_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> MONU_KEY = ck("grave_monument");
    public static final class_1792 GRAVE_MONUMENT = new class_1792(new class_1792.class_1793().method_63686(MONU_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> GALLOWS_KEY = ck("gallows_cage");
    public static final class_1792 GALLOWS_CAGE = new class_1792(new class_1792.class_1793().method_63686(GALLOWS_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> SPIKE_KEY = ck("skull_spike");
    public static final class_1792 SKULL_SPIKE = new class_1792(new class_1792.class_1793().method_63686(SPIKE_KEY).method_7889(1).method_7894(class_1814.field_8904));

    // ===== DUEL ARENA set — the Duel Greatsword + colosseum structures =====
    public static final class_5321<class_1792> SWORD_KEY = ck("duel_sword");
    public static final class_1792 DUEL_SWORD = new class_1792(new class_1792.class_1793().method_63686(SWORD_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> APILLAR_KEY = ck("arena_pillar");
    public static final class_1792 ARENA_PILLAR = new class_1792(new class_1792.class_1793().method_63686(APILLAR_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> AARCH_KEY = ck("arena_arch");
    public static final class_1792 ARENA_ARCH = new class_1792(new class_1792.class_1793().method_63686(AARCH_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> HAND_KEY = ck("god_hand");
    public static final class_1792 GOD_HAND = new class_1792(new class_1792.class_1793().method_63686(HAND_KEY).method_7889(1).method_7894(class_1814.field_8904));

    // ===== OCEAN WORLD set — the Sea Trident + undersea structures =====
    public static final class_5321<class_1792> TRIDENT_KEY = ck("sea_trident");
    public static final class_1792 SEA_TRIDENT = new class_1792(new class_1792.class_1793().method_63686(TRIDENT_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> SHARK_KEY = ck("shark");
    public static final class_1792 SHARK = new class_1792(new class_1792.class_1793().method_63686(SHARK_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> CORAL_KEY = ck("coral_pillar");
    public static final class_1792 CORAL_PILLAR = new class_1792(new class_1792.class_1793().method_63686(CORAL_KEY).method_7889(1).method_7894(class_1814.field_8904));
    public static final class_5321<class_1792> TEMPLE_KEY = ck("sea_temple");
    public static final class_1792 SEA_TEMPLE = new class_1792(new class_1792.class_1793().method_63686(TEMPLE_KEY).method_7889(1).method_7894(class_1814.field_8904));

    @Override
    public void onInitialize() {
        class_2378.method_39197(class_7923.field_41178, SHADES_KEY, VOID_SHADES);
        class_2378.method_39197(class_7923.field_41178, DRONE_KEY, VOID_DRONE);
        class_2378.method_39197(class_7923.field_41178, SAT_KEY, VOID_SATELLITE);
        class_2378.method_39197(class_7923.field_41178, GEAR_KEY, VOID_GEAR);
        class_2378.method_39197(class_7923.field_41178, CORE_KEY, VOID_CORE);
        class_2378.method_39197(class_7923.field_41178, FAN_KEY, CROW_FAN);
        class_2378.method_39197(class_7923.field_41178, CROW_KEY, CROW);
        class_2378.method_39197(class_7923.field_41178, TOMB_KEY, TOMBSTONE);
        class_2378.method_39197(class_7923.field_41178, TORII_KEY, TORII);
        class_2378.method_39197(class_7923.field_41178, TREE_KEY, DEAD_TREE);
        class_2378.method_39197(class_7923.field_41178, MONU_KEY, GRAVE_MONUMENT);
        class_2378.method_39197(class_7923.field_41178, GALLOWS_KEY, GALLOWS_CAGE);
        class_2378.method_39197(class_7923.field_41178, SPIKE_KEY, SKULL_SPIKE);
        class_2378.method_39197(class_7923.field_41178, SWORD_KEY, DUEL_SWORD);
        class_2378.method_39197(class_7923.field_41178, APILLAR_KEY, ARENA_PILLAR);
        class_2378.method_39197(class_7923.field_41178, AARCH_KEY, ARENA_ARCH);
        class_2378.method_39197(class_7923.field_41178, HAND_KEY, GOD_HAND);
        class_2378.method_39197(class_7923.field_41178, TRIDENT_KEY, SEA_TRIDENT);
        class_2378.method_39197(class_7923.field_41178, SHARK_KEY, SHARK);
        class_2378.method_39197(class_7923.field_41178, CORAL_KEY, CORAL_PILLAR);
        class_2378.method_39197(class_7923.field_41178, TEMPLE_KEY, SEA_TEMPLE);
        // multiplayer effect-sharing networking
        VoidNet.registerCommon();
        VoidNet.registerServer();
        // show up in the Combat creative tab
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202)
            .register(entries -> {
                entries.method_45421(VOID_SHADES); entries.method_45421(VOID_DRONE); entries.method_45421(VOID_SATELLITE);
                entries.method_45421(CROW_FAN); entries.method_45421(DUEL_SWORD); entries.method_45421(SEA_TRIDENT);
            });
    }
}
